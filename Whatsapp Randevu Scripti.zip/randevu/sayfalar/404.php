<div class="container-fluid">
  <div class="row">
    <div class="col-xl-12 col-sm-6 mb-3 text-center">
     <h1 class="display-1">404</h1>
     <p class="lead">Sayfa bulunamadı. <a href="javascript:history.back()">Önceki sayfaya</a>
      geri dönebilir veya <a href="?sayfa=anasayfa">anasayfaya</a> dönebilirsiniz.</p>
    </div>
  </div>
</div>