<?php
session_start();

	include 'conn.php';
	include 'head.php';

?>

<style>

body{margin:0;}

</style>

<div class="block shadow">

<div style="width:550px; margin:auto;">

<?php 

$blockuyelercek = $db->prepare("SELECT * FROM engel where engelleyen=?");
$blockuyelercek ->execute(array($_SESSION["kullanici"]));
$blocksay = $blockuyelercek ->rowCount();
$blockuyeler = $blockuyelercek ->fetchAll(PDO::FETCH_ASSOC);
foreach ($blockuyeler as $block){ 

$blockuyelercek2 = $db->prepare("SELECT * FROM uyeler where kullanici=?");
$blockuyelercek2 ->execute(array($block["engellenen"]));
$blockuyeler2 = $blockuyelercek2 ->fetchAll(PDO::FETCH_ASSOC);
foreach ($blockuyeler2 as $block2){ 

?>



<div class="block-a">

<div class="block-img"><a href="user/<?php echo $block["engellenen"] ?>"><img src="<?php echo $block2["fotograf"] ?>" width="50" height="50"></a></div>
<div class="block-t">
<div class="block-t2"><a href="user/<?php echo $block["engellenen"] ?>"><?php echo $block["engellenen"] ?></a></div>
<div class="block-t2"><a href="delete.php?block=<?php echo $block["engellenen"] ?>">Engeli Kaldır</a></div>
</div>


</div>



<?php } } 
	
	if($blocksay <= "0"){ ?>
    
        <div style="margin-top:25px; text-align:center; font-size: 25px; font-family: 'Courgette', cursive;">Gizlediğin kimse yok!</div>   
    

	
	<?php } ?>

</div>

</div>	

