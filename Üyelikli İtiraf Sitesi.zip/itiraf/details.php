<?php

ob_start();
session_start();

	include 'conn.php';
	
	$act = $_GET["act"];
	$sehir = $_GET["city"];

	

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include_once 'head.php';

	if ($iphone || $android || $palmpre || $ipod || $berry == true)
{  header('location: '.$siteurl.'mobile'.$_SERVER['REQUEST_URI'].''); }
	

 ?>
</head>

<body>


<div class="covering">


<?php include 'menu.php'; ?>

<div class="cov-a">

<?php if($solreklam != ""){ include 'ads/left.php'; } ?>

<div class="content">

    
<?php include 'confession.php'; ?>

<?php 

if($itirafsay >= "1"){ 

?>

<iframe name="comment" src="<?php echo $siteurl ?>comment.php?id=<?php echo $itiraf["id"] ?>" class="likeframe" width="750" height="485" frameborder="0" scrolling="no" style="border-radius:5px; margin-bottom:10px;"></iframe>
	

<div class="shadow" style="width:750px; padding:10px 0; text-align:center; background:#FFF; color:#999; border-radius: 5px; font-family: 'Courgette', cursive;"><font color="crimson">İTİRAF URL:</font> <font color="#099"><?php echo "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?></font></div>

<div class="shadow" style="padding:10px 20px; display:table; margin:auto; margin-top:10px; background:#FFF; color:#999; border-radius: 5px; font-family: 'Courgette', cursive;">

<div class="sharer" style="float: left; margin-right: 5px;"> 
  
 <div class="fb-share-button" data-href="https://fevolin.com/<?php echo $_SESSION["kullanici"]; ?>" data-layout="button" data-size="large" data-mobile-iframe="true"><a class="fb-xfbml-parse-ignore" target="_blank" href="https://www.facebook.com/sharer/sharer.php?u=<?php echo "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>"><img src="img/social/facebook2.png" width="30" height="30" alt="Facebook" title="Facebook'ta Paylaş" /></a></div></div>
 
 <div class="sharer" style="float: left;">
 
 <a href="http://twitter.com/intent/tweet?url=<?php echo "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>&text=İtirafa göz at!&original_referer=http://twitter.com/intent/tweet?url=<?php echo "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>&text=İtirafa göz at!&original_referer=<?php echo "https://".$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI']; ?>&related=itiraf2com&via=itiraf2com&related=f&via=itiraf2com" target="_blank"> 
 <img src="img/social/twitter2.png" width="30" height="30" alt="Twitter" title="Twitter'da Paylaş" /></a></div>
  </div>

<head><title><?php echo $itiraf["yazan"]?> kişisinin itirafı - <?php echo $sitename ?></title></head>

<?php }else{ ?>

<head><title>İtiraf bulunamadı! - <?php echo $sitename ?></title></head>

<?php } ?>

<?php include 'footer.php'; ?>

</div>

<?php if($sagreklam != ""){ include 'ads/right.php'; } ?>

</div>

</div>

</body>
</html>

<?php ob_end_flush();  ?>