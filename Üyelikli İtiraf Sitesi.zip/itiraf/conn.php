<?php
try {
     $db = new PDO("mysql:host=localhost;dbname=camixonl_itiraf1;charset=utf8", "camixonl_itiraf1", "mevlutcan1");
} catch ( PDOException $e ){
     print $e->getMessage();
}
error_reporting(0);
	

	$siteayarlar = $db->prepare("SELECT * FROM ayarlar where id=?");
	$siteayarlar->execute(array("1"));
	$ayar = $siteayarlar->fetch(PDO::FETCH_ASSOC);
		
	$ceo 			= $ayar["ceo"];	
	$siteurl 		= $ayar["siteurl"];
	$sitename 		= $ayar["sitename"];
	$itirafuzunluk  = $ayar["itiraf_uzunluk"];
	$yorumuzunluk  = $ayar["yorum_uzunluk"];
	$itiraflimit    = $ayar["itiraf_gorunen_limit"];
	$instagram   	= $ayar["instagram"];
	$kullaniciyazi 	= $ayar["kullanici_sozlesmesi_yazi"];
	$gizlilikyazi  	= $ayar["gizlilik_cerez_yazi"];	
	$siteyasalyazi  = $ayar["site_yasal_yazi"];	
	$reklamyazi   	= $ayar["reklam_yazi"];	
	

	$solreklamcek = $db->prepare("SELECT * FROM reklam where konum=?");
	$solreklamcek->execute(array("sol"));
	$solreklam2 = $solreklamcek->fetch(PDO::FETCH_ASSOC);
	
	$sagreklamcek = $db->prepare("SELECT * FROM reklam where konum=?");
	$sagreklamcek->execute(array("sag"));
	$sagreklam2 = $sagreklamcek->fetch(PDO::FETCH_ASSOC);
	
	$ortareklamcek = $db->prepare("SELECT * FROM reklam where konum=? order by rand() limit 1");
	$ortareklamcek->execute(array("orta"));
	$ortareklam2 = $ortareklamcek->fetch(PDO::FETCH_ASSOC);
	
	$telefonreklamcek = $db->prepare("SELECT * FROM reklam where konum=? order by rand() limit 1");
	$telefonreklamcek->execute(array("telefon"));
	$telefonreklam2 = $telefonreklamcek->fetch(PDO::FETCH_ASSOC);
	
	
	$solreklam   	= $solreklam2["reklam"];	
	$sagreklam   	= $sagreklam2["reklam"];	
	$ortareklam   	= $ortareklam2["reklam"];	
	$telefonreklam 	= $telefonreklam2["reklam"];	
	
if($_COOKIE["onlitm"]){

$parcala = explode("___",$_COOKIE["onlitm"]);
$usercookie = $parcala[0];
$passcookie = $parcala[1];

if(!$_SESSION){
	
$l = $db->prepare("select * from uyeler where kullanici=? and sifre=?");
	
$l->execute(array($usercookie,$passcookie));

$x = $l->fetch(PDO::FETCH_ASSOC);

$d = $l->rowCount();  
	
if($d){
	
	$_SESSION["kullanici"]  	= $x["kullanici"];
	$_SESSION["eposta"] 		= $x["eposta"];
	$_SESSION["cinsiyet"] 		= $x["cinsiyet"];
	$_SESSION["fotograf"] 		= $x["fotograf"];
	$_SESSION["sehir"] 			= $x["sehir"];
	$_SESSION["begeni"] 		= $x["begeni"];
	$_SESSION["facebook"] 		= $x["facebook"];
	$_SESSION["twitter"] 		= $x["twitter"];
	$_SESSION["instagram"] 		= $x["instagram"];
	$_SESSION["youtube"] 		= $x["youtube"];
	$_SESSION["onay"] 			= $x["onay"];
	$_SESSION["son_giris"] 		= $x["son_giris"];
	$_SESSION["kayit"] 			= $x["kayit"];
		

		
}
	
}
	
}
					
?>

<base href="<?php echo $siteurl ?>" />