<?php 

ob_start();
session_start();

	include 'conn.php';
	
	
	$begen 		= $_GET["like"];
	$emoji 		= $_GET["e"];
	$ben   		= $_SESSION["kullanici"];
	$itiraf		= $_GET["conf"];
	$block  	= $_GET["block"];
	$fotograf   = $_GET["photo"];
	$yorum	    = $_GET["comment"];
	
if($begen){

	
		$itirafpaylasanbul = $db->prepare("SELECT * FROM itiraf where id=?");
		$itirafpaylasanbul->execute(array($begen));
		$itirafyaplasan = $itirafpaylasanbul->fetch(PDO::FETCH_ASSOC);
		
	$user  = $itirafyaplasan["yazan"];
	
		$begenibulcek = $db->prepare("SELECT * FROM uyeler where kullanici=?");
		$begenibulcek->execute(array($user));
		$begenibul = $begenibulcek->fetch(PDO::FETCH_ASSOC);

	$silbegeni2 = $begenibul["begeni"]-1;
		
	
	$itirafuyelercek = $db->prepare("SELECT * FROM begeniler where begenen=? and begenilen_id=?");
	$itirafuyelercek ->execute(array($ben, $begen));
	$begenivarmi = $itirafuyelercek ->rowCount();
	
	
	if($begenivarmi >= "1"){
	
		$silbegeni = $db->prepare("delete from begeniler where begenen=? and begenilen_id=?");
		$silbegeni->execute(array($ben, $begen));
			
			if ($silbegeni){ 
		
	$guncellebegeni = $db->prepare("update uyeler set begeni=? where kullanici=?");
	$guncellebegeni->execute(array($silbegeni2, $user));
		
		
		header("location: ".$_SERVER['HTTP_REFERER']."");
			
	}
	
		
	}
		
	
	}


if($itiraf){
	
		$itirafkimin2 = $db->prepare("SELECT * FROM itiraf where id=? and yazan=?");
		$itirafkimin2->execute(array($itiraf, $ben));
		$itirafkimin = $itirafkimin2->rowCount();
		
	if($itirafkimin <= "0"){
		
		header("location: ".$_SERVER['HTTP_REFERER']."");

	}else{
		
		$silitiraf = $db->prepare("delete from itiraf where yazan=? and id=?");
		$silitiraf->execute(array($ben, $itiraf));
		
		if($silitiraf){
			
		$silbegeni = $db->prepare("delete from begeniler where begenilen_id=?");
		$silbegeni->execute(array($itiraf));
			
			if($silbegeni){
					
		$silyorum = $db->prepare("delete from yorumlar where yapilan_id=?");
		$silyorum->execute(array($itiraf));
			
			if($silyorum){
				
				header("location: ".$_SERVER['HTTP_REFERER']."");
			
			}
			
			}
			
			}
		
		}
	
	
	
	}
	
	
if($block){
	
		$blockvarmicek = $db->prepare("SELECT * FROM engel where engellenen=? and engelleyen=?");
		$blockvarmicek->execute(array($block, $ben));
		$blockvarmi = $blockvarmicek->rowCount();
		
	if($blockvarmi <= "0"){
		
		header("location: ".$_SERVER['HTTP_REFERER']."");

	}else{
		
		$silblock = $db->prepare("delete from engel where engelleyen=? and engellenen=?");
		$silblock->execute(array($ben, $block));
		
		if($silblock){
			

				
				header("location: ".$_SERVER['HTTP_REFERER']."");
		
			
			}
		
		}
	
	
	
	}
	

if($fotograf){
	
	if($_SESSION){
	
		$fotobenimmicek = $db->prepare("SELECT * FROM uyeler where fotograf=? and kullanici=?");
		$fotobenimmicek->execute(array($fotograf, $ben));
		$fotobenimmi = $fotobenimmicek->rowCount();
	
	if($fotobenimmi >= "1"){
	
	unlink($fotograf);
	
	$guncellefoto = $db->prepare("update uyeler set fotograf=? where kullanici=?");
	$guncellefoto->execute(array("img/no-photo.png", $ben));
			
			if ($guncellefoto){ 
			
		
		header("location: ".$_SERVER['HTTP_REFERER']."");
			
	}
	
	}
	
	}else{
		
		header("location: ".$_SERVER['HTTP_REFERER']."");
		
		}
	
	}



if($yorum){
	
		$yorumvarmicek = $db->prepare("SELECT * FROM yorumlar where id=?");
		$yorumvarmicek->execute(array($yorum));
		$yorumvarmi = $yorumvarmicek->rowCount();
		
	if($yorumvarmi <= "0"){
		
		header("location: ".$_SERVER['HTTP_REFERER']."");

	}else{
		
		$silincekyorumcek = $db->prepare("SELECT * FROM yorumlar where id=?");
		$silincekyorumcek ->execute(array($yorum));
		$silincekyorum = $silincekyorumcek ->fetch(PDO::FETCH_ASSOC);

		if($silincekyorum["yapan"] == $ben or $silincekyorum["yapilan"] == $ben){
		
		$silyorum = $db->prepare("delete from yorumlar where id=?");
		$silyorum->execute(array($yorum));
		
		if($silyorum){
			

				
				header("location: ".$_SERVER['HTTP_REFERER']."");
		
			
			}
		
		}
		
		}
	
	
	
	}



header("location: ".$_SERVER['HTTP_REFERER']."");


ob_end_flush();

?>