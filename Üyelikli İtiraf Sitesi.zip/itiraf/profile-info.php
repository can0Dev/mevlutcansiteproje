<style>



</style>

<div class="profile-info shadow">

<?php 

		$profiluyecek2 = $db->prepare("SELECT * FROM uyeler where kullanici=?");
		$profiluyecek2->execute(array($userp));
		$profil2 = $profiluyecek2->fetch(PDO::FETCH_ASSOC);

		$itiraflarisay = $db->prepare("SELECT * FROM itiraf where yazan=?");
		$itiraflarisay->execute(array($userp));
		$itirafsay = $itiraflarisay->rowCount();

		include 'profile-emoji.php';		

?>

<div class="p-i-box">


<div class="p-i-img" style="background:url(<?php echo $profil2["fotograf"] ?>); background-size:cover;"><a href="<?php echo $profil2["fotograf"] ?>" target="_blank"><div style="width:110px; height:110px; border-radius:50%;"></div></a></div>


<div class="p-i-t" id="approved"><?php if($profil2["sayfa_adi"] == ""){ echo $profil2["kullanici"]; }else{ echo $profil2["sayfa_adi"]; } if($profil2["onay"] == "1"){ ?> 

<div style="display: table;float: right;margin-left: 5px; position:relative;">
<img src="img/icon/approved.png" width="21" height="21" />

<div class="tit-hov" style="left: -35px; bottom: -50px; background:#f1f1f1; color:#000;">
<div class="e-hov-u" style="background:#f1f1f1;"></div>
Onaylanmış Hesap
</div>
</div>

 <?php } ?></div>
<div class="p-i-t"><?php echo $profil2["cinsiyet"] ?></div>
<div class="p-i-t"><?php if($profil2["sehir"] == ""){echo 'Şehir Belirtilmedi'; }else{ echo $profil2["sehir"]; } ?></div>


<div class="p-i-t">

<?php if($profil2["facebook"] != ""){ ?>

<div class="p-i-s" id="facebook">
<a href="https://www.facebook.com/<?php echo $profil2["facebook"] ?>" target="_blank"><img src="img/social/facebook.png" width="25" height="25" /></a>

<div class="tit-hov" style="left:-26px; bottom: -35px;">
<div class="e-hov-u"></div>
Facebook
</div>

</div> 

<?php } ?>

<?php if($profil2["twitter"] != ""){ ?>

<div class="p-i-s" id="twitter">
<a href="https://www.twitter.com/<?php echo $profil2["twitter"] ?>" target="_blank"><img src="img/social/twitter.png" width="25" height="25" /></a>

<div class="tit-hov" style="left:-20px; bottom: -35px;">
<div class="e-hov-u"></div>
Twitter
</div>

</div>

<?php } ?>

<?php if($profil2["instagram"] != ""){ ?>

<div class="p-i-s" id="instagram">
<a href="https://www.instagram.com/<?php echo $profil2["instagram"] ?>" target="_blank"><img src="img/social/instagram.png" width="25" height="25" /></a>

<div class="tit-hov" style="left:-29px; bottom: -35px;">
<div class="e-hov-u"></div>
İnstagram
</div>

</div>

<?php } ?>


<?php if($profil2["youtube"] != ""){ ?>

<div class="p-i-s" id="youtube">
<a href="https://www.youtube.com/<?php echo $profil2["youtube"] ?>" target="_blank"><img src="img/social/youtube.png" width="25" height="25" /></a>

<div class="tit-hov" style="left:-22px; bottom: -35px;">
<div class="e-hov-u"></div>
Youtube
</div>

</div>

<?php } ?>

</div>


</div>



<div class="p-i-box">

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="img/emoji/heart.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $kalpbegenip ?></div>

</div>

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="img/emoji/smile.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $gulenbegenip ?></div>
</div>

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="img/emoji/angry.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $sinirlibegenip ?></div>
</div>

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="img/emoji/sad.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $uzgunbegenip ?></div>
</div>

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="img/emoji/confused.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $saskinbegenip ?></div>
</div>


<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="img/emoji/comment.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $itirafyorum1 ?></div>
</div>

<?php $toplambegenip = $kalpbegenip+$gulenbegenip+$asikbegenip+$sinirlibegenip+$uzgunbegenip+$saskinbegenip ?>
<div class="p-i-i-box">
<div class="p-i-i-box-t">Toplam İfade: <?php echo $toplambegenip ?></div>
</div>

<div class="p-i-i-box">
<div class="p-i-i-box-t">Toplam İtiraf: <?php echo $itirafsay ?></div>
</div>

</div>

</div>

<?php if($_SESSION["kullanici"] == $userp){ ?>

<div class="userp-panel">

<div class="userp" style="margin-left:0;">
<a href="user/<?php echo $userp ?>/confession"><img src="img/icon/confession.png" width="20" height="20" /></a>

<div class="tit-hov" style="left:-24px; bottom: -35px; background:#f1f1f1; color:#000;"">
<div class="e-hov-u" style="background:#f1f1f1;"></div>
İtiraflarım
</div>

</div>

<div class="userp">
<a href="user/<?php echo $userp ?>/block"><img src="img/icon/block.png" width="20" height="20" /></a>

<div class="tit-hov" style="left:2px; bottom: -51px; background:#f1f1f1; color:#000;">
<div class="e-hov-u" style="background:#f1f1f1;"></div>
Gizlenen Kullanıcılar
</div>

</div>

<div class="userp" <?php if($profil2["eposta"] == ""){ ?>style="background:coral;"<?php } ?>>
<a href="user/<?php echo $userp ?>/settings"><img src="img/icon/settings.png" width="20" height="20" /></a>

<div class="tit-hov" style="left:53px; bottom: -35px; background:#f1f1f1; color:#000;"">
<div class="e-hov-u" style="background:#f1f1f1;"></div>
Ayarlar
</div>

</div>


</div>

<?php } ?>

<?php if($_SESSION["kullanici"] == $userp){ ?>

<div class="profile-link shadow"><font color="crimson">Profil Link:</font> <?php echo $siteurl ?>user/<?php echo $userp ?></div>

<?php } ?>
