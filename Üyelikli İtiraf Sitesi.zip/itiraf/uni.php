<?php

ob_start();
session_start();

	include 'conn.php';
	
	$songiris 	= time();

	$uni = $_GET["university"];

		
		$univerktit = $db->prepare("SELECT * FROM universite where seo=?");
		$univerktit->execute(array($uni));
		$uniktit = $univerktit->fetch(PDO::FETCH_ASSOC);
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<?php include 'head.php'; ?>
<?php if($uni){ ?> <title><?php echo $unitit["universite"]." İtirafları - ".$sitename ?></title> <?php } ?>

</head>

<body>


<div class="covering">


<?php include 'menu.php'; ?>

<div class="cov-a">

<?php if(!$act){ include 'city-uni.php'; } ?>

<?php if($solreklam != ""){ include 'ads/left.php'; } ?>

<div class="content">

<?php include 'flow.php'; ?>

<?php include 'confession.php'; ?>


<?php include 'pagination.php'; ?>

<?php include 'footer.php'; ?>

</div>

<?php if($sagreklam != ""){ include 'ads/right.php'; } ?>

</div>

</div>

</body>
</html>

<?php ob_end_flush();  ?>