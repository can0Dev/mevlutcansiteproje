<?php

ob_start();
session_start();

	include 'conn.php';
	
	$songiris 	= time();
	
	$act = $_GET["act"];
	$sehir = $_GET["city"];
	$uni = $_GET["university"];

		$sehirlericektit = $db->prepare("SELECT * FROM sehirler where seo=?");
		$sehirlericektit->execute(array($sehir));
		$sehirtit = $sehirlericektit->fetch(PDO::FETCH_ASSOC);
		
		$univerktit = $db->prepare("SELECT * FROM universite where seo=?");
		$univerktit->execute(array($uni));
		$uniktit = $univerktit->fetch(PDO::FETCH_ASSOC);
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<?php include 'head.php'; ?>
<?php if($act == "login"){ ?> <title>Giriş Yap - <?php echo $sitename ?></title> <?php } ?>
<?php if($act == "signup"){ ?> <title>Kayıt Ol - <?php echo $sitename ?></title> <?php } ?>
<?php if($act == "flow-now"){ ?> <title>Akış - Şimdi - <?php echo $sitename ?></title> <?php } ?>
<?php if($act == "flow-1-hour-ago"){ ?> <title>Akış - 1 saat ve öncesi - <?php echo $sitename ?></title> <?php } ?>
<?php if($act == "flow-1-day-ago"){ ?> <title>Akış - 1 gün ve öncesi - <?php echo $sitename ?></title> <?php } ?>
<?php if($act == "flow-1-week-ago"){ ?> <title>Akış - 1 hafta ve öncesi - <?php echo $sitename ?></title> <?php } ?>
<?php if($sehir){ ?> <title><?php echo $sehirtit["sehir"]." Şehrindeki İtiraflar - ".$sitename ?></title> <?php } ?>
<?php if($uni){ ?> <title><?php echo $uniktit["universite"]." İtirafları - ".$sitename ?></title> <?php } ?>
<?php if(!$act and !$sehir and !$uni){ ?> <title><?php echo $sitename ?></title> <?php } ?>

</head>

<body>


<div class="covering">

	<?php 
	
	if(!$act or !$sehir or !$uni){
    
    if($_SESSION){
		
	if($_SESSION["kullanici"] != $ceo){
		
			if($_SESSION["kullanici"] != "reklam"){
		
	$guncellegiris = $db->prepare("update uyeler set son_giris=? where kullanici=?");
	$guncellegiris->execute(array($songiris, $_SESSION["kullanici"]));
	
	}
	
	}   }	}
	
	?>

<?php include 'menu.php'; ?>

<div class="cov-a">

<?php if(!$act){ include 'city-uni.php'; } ?>

<?php if($solreklam != ""){ include 'ads/left.php'; } ?>

<div class="content">

<?php if(!$sehir and !$uni){ include 'confession-share.php'; } ?>


<?php include 'flow.php'; ?>

<?php include 'confession.php'; ?>


<?php if(!$act and !$sehir and !$uni){ ?>
    
<div class="no-conf-t" style="width:750px; font-size:22px; display:table; padding:10px 0; background:#fff; border-radius:5px;">
	Hepsini okudun!
    <br />
    <a href="<?php echo $siteurl ?>" style="color:#777; outline:none; text-decoration:none;">Değiştir</a>    
</div>
    
    <?php } ?>

<?php include 'pagination.php'; ?>

<?php include 'footer.php'; ?>

</div>

<?php if($sagreklam != ""){ include 'ads/right.php'; } ?>

</div>

</div>

</body>
</html>

<?php ob_end_flush();  ?>