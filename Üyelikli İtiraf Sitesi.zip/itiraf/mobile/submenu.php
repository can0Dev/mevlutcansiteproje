<?php

	$benimbilgiler = $db->prepare("SELECT * FROM uyeler where kullanici=?");
	$benimbilgiler->execute(array($_SESSION["kullanici"]));
	$benim = $benimbilgiler->fetch(PDO::FETCH_ASSOC);
	
		
		$bildirimsaycek = $db->prepare("SELECT * FROM yorumlar where yapilan=? and goruldumu=?");
		$bildirimsaycek->execute(array($_SESSION["kullanici"], "0"));
		$bildirimsay = $bildirimsaycek->rowCount();
	
	?>
   
    




<div class="submenu-a">

<div class="pcenter">

<div class="submenu"><a href="search.php">Ara</a></div>

<div class="submenu"><a href="fl-ci.php?ci=1">Şehir-Üni...</a></div>

<div class="submenu"><a href="fl-ci.php?fl=1">Akış</a></div>

<?php if($_SESSION){ ?>

<div class="submenu"><a href="user/<?php echo $benim["kullanici"] ?>/confession" <?php if($bildirimsay >= "1"){ ?> style="color:coral;" <?php } ?> >Profil</a></div>

<?php } ?>

</div>

</div>



