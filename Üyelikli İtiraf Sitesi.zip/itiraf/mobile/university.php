<?php 
	
		$universitelericek = $db->prepare("SELECT * FROM universite");
		$universitelericek->execute(array());
		$universiteleri = $universitelericek->fetchAll(PDO::FETCH_ASSOC);
		foreach ($universiteleri as $universite){ 
	
?>
    
    <option value="<?php echo $universite["seo"] ?>"><?php echo $universite["universite"] ?></option>

<?php } ?>