<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/main.css" />
<link rel="stylesheet" type="text/css" href="css/phone.css" />

<?php include 'function.php'; ?>

<link rel="shortcut icon" href="<?php echo $siteurl ?>img/favicon.png">

<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet"> 
<link href="https://fonts.googleapis.com/css?family=Libre+Baskerville" rel="stylesheet">  

<meta name="title" content="İtiraf2">
<meta name="description" content="İtiraf paylaş, şehrindeki yada üniversitendenki itirafları hemen oku!">
<meta name="keywords" content="itiraflar, itiraf oku, itiraf paylaş, istanbul itiraflar, izmir itiraflar, ankara itiraflar, adana itiraflar">
<meta name="robots" content="index, follow">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
<meta name="language" content="Turkish">
<meta name="revisit-after" content="1 days">
<meta name="author" content="İtiraf2">


<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-118832196-3"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-118832196-3');
</script>


<?php

$iphone = strpos($_SERVER['HTTP_USER_AGENT'],"iPhone");
$android = strpos($_SERVER['HTTP_USER_AGENT'],"Android");
$palmpre = strpos($_SERVER['HTTP_USER_AGENT'],"webOS");
$berry = strpos($_SERVER['HTTP_USER_AGENT'],"BlackBerry");
$ipod = strpos($_SERVER['HTTP_USER_AGENT'],"iPod");

if ($iphone || $android || $palmpre || $ipod || $berry == true){  }else{header('location: '.$siteurl2.''); }

?>