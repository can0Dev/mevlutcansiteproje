<?php

ob_start();
session_start();

	include 'conn.php';
	
	$sehir = $_GET["city"];

	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include 'head.php'; ?>
<title>İtiraf</title>
</head>

<body>

<div class="covering">


<?php include 'menu.php'; ?>

<div class="cov-a">



<div class="content">

<div class="fl-ci-box">

<div style="margin:auto; display:table;">

<?php

if($_GET["ci"] == "1"){

?>

<form action="go.php" method="get" style="margin:0;">

<select class="conf-select" style="width:50%; padding:15px; margin-top:7px; margin-left:0;" name="city2">

	<option selected disabled hidden>Şehir İtirafları</option>
	<?php include 'city.php'; ?>
    </select>

<input type="submit" class="conf-submit" style="width:200px; margin-left: -10px; padding: 16px; margin-top: 7px; background: #fff; border: 1px #ccc solid;" value="Listele" />
</form>
<div style="margin:40px 0; height:1px; width:50%;"></div>
<form action="go.php" method="get" style="margin:0;">

<select class="conf-select" style="width:50%; padding:15px; margin-top:7px; margin-left:0;" name="university">

	<option selected disabled hidden>Üniversite İtirafları</option>
	<?php include 'university.php'; ?>
    </select>

<input type="submit" class="conf-submit" style="width:200px; margin-left: -10px; padding: 16px; margin-top: 7px; background: #fff; border: 1px #ccc solid;" value="Listele" />

</form>


<?php }elseif($_GET["fl"] == "1"){ ?>


<form action="index.php" method="get" style="margin:0;">

<select class="conf-select" style="width:50%; padding:15px; margin-top:7px; margin-left:0;" name="act">

	<option selected disabled hidden>Akış</option>
	    <option value="flow-now">Şimdi</option>
        <option value="flow-1-hour-ago">1 saat ve öncesi</option>
        <option value="flow-1-day-ago">1 gün ve öncesi</option>
        <option value="flow-1-week-ago">1 hafta ve öncesi</option>
    </select>

<input type="submit" class="conf-submit" style="width:200px; margin-left: -10px; padding: 16px; margin-top: 7px; background: #fff; border: 1px #ccc solid;" value="Listele" />
</form>

<?php }else{ header("location: ".$siteurl."");} ?>

</div>

</div>

<?php include 'footer.php'; ?>

</div>

</div>


<?php include 'submenu.php'; ?>

</div>

</body>
</html>
