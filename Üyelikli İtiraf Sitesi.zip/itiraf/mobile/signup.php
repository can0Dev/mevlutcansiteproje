<?php 

if($_SESSION){
		
		header('location: '.$siteurl.'');
		
		}	
		
		?>
        
<div class="share-a-confession">

<div class="siglog-t-a">
<div class="siglog-t">KAYIT OL</div>
</div>

<form action="" method="post">

<div class="center">
<input type="text" class="conf-input" style="margin-top:5px;" placeholder="Kullanıcı Adı" name="username" maxlength="20" required="required" />
</div>

<div class="center">
<input type="password" class="conf-input" style="margin-top:-20px;" placeholder="Şifre" name="password" maxlength="20" required="required" />
</div>

<div class="center">
<select class="conf-select" name="gender" style="width:270px; padding:10px; margin-top:-20px;">

	<option selected disabled hidden>Cinsiyet</option>
    <option value="Erkek">Erkek</option>
    <option value="Kadın">Kadın</option>
    
</select>
</div>

<div class="center" style="margin-top:-10px;">

<div class="legal-chbx-a">
<div class="legal-chbx">

<input type="checkbox" id="checkboxFourInput" style="visibility:hidden;" name="chcbx" /> <label for="checkboxFourInput"></label> 

</div>
<div class="legal-chbx-t"><a href="page/user-agreement" target="_blank" style="color:#099; outline:none; text-decoration:none;">Kullanıcı sözleşmesini,</a> <a href="page/site-legal-rights" target="_blank" style="color:#099; outline:none; text-decoration:none;">site yasal haklarını</a> okudum ve kabul ediyorum.</div>
</div>
</div>

<div class="center" style="margin-top:-20px;">
<input type="submit" class="conf-submit" value="Kayıt Ol" />
</div>

</form>

<div class="center" style="padding:0 0 15px 0; margin-top:-20px;">

<div class="login" style="width:260px; margin-right:0;font-family: 'Courgette', cursive;"><a href="login">Hesabın varsa giriş yap</a></div>

</div>

<?php 

@$kullanici = strip_tags(html_entity_decode($_POST["username"]));
@$sifre2	= strip_tags(html_entity_decode($_POST["password"]));
@$sifre		= strip_tags(html_entity_decode(md5($_POST["password"])));
@$yasal		= $_POST["chcbx"];
@$cinsiyet	= strip_tags(html_entity_decode($_POST["gender"]));
$tarih 		= date("d.m.Y");
$ip 		= $_SERVER['REMOTE_ADDR'];

$degisecekler = array("ğ", "ö", "ç", "ş", "ı", "ü", "Ü", "Ş", "Ğ", "Ö", "Ç", "İ", " ");
$yeniler   = array("g", "o", "c", "s", "i", "u", "u", "s", "g", "o", "c", "i", "");

$kuladi12 = str_replace($degisecekler, $yeniler, $kullanici); 
$kuladi  = strtolower($kuladi12); 


?>

</form>

<?php

if($_POST){
	
	
	if($yasal == ""){ ?>
    <div style="margin-top:-20px; border:2px red solid; padding:10px; background:#FFF; border-radius:5px;">
    <div style="font-size: 40px; margin:10px; color:red; text-align:center;">Tüm alanların dolu olup, <b style="color:#099;">Kullanıcı sözleşmesi ve site yasal haklarının</b> kabul edilmiş olması gerekmektedir!</div>
     </div>
	
	<?php }else{
		
		if(strlen($kullanici) < 6){ echo'<br><center><div style="margin-top:-20px; border:2px red solid; padding:10px; background:#FFF; border-radius:5px;"><font color="red" style="font-size:40px;">Kullanıcı adı en az 6 karakter olmalı!</font></div></center>';}
		elseif(strlen($sifre2) < 6){ echo'<br><center><div style="margin-top:-20px; border:2px red solid; padding:10px; background:#FFF; border-radius:5px;"><font color="red" style="font-size:40px;">Şifre en az 6 karakter olmalı!</font></div></center>';}
		
		else{
			
			
	$varmikadi = $db->prepare("SELECT * FROM uyeler WHERE kullanici=?");
	$varmikadi->execute(array($kuladi));
	$okutalim = $varmikadi->rowCount();

	
	if ($okutalim > "0"){
		echo '<br><center><div style="margin-top:-20px; border:2px red solid; padding:10px; background:#FFF; border-radius:5px;"><font color="red" style="font-size:40px;">Kullanıcı adı başkası tarafından kullanılıyor!</font></div></center>';
		}else{
						
	$kayit = $db->prepare("INSERT INTO uyeler SET  kullanici=?, sifre=?, cinsiyet=?, kayit=?, ipadres=?");
	$kayit->execute(array(trim($kuladi), trim($sifre), $cinsiyet, $tarih, $ip));

	if ($kayit){ // BURADASI KAYIT BASARILI KISMI
		
		// OTOMATİK GİRİŞ BAŞLANGIÇ
		
$l = $db->prepare("select * from uyeler where kullanici=? and sifre=?");

if($_POST){
	
$l->execute(array($kuladi,$sifre));

$x = $l->fetch(PDO::FETCH_ASSOC);

$d = $l->rowCount();

if($d){
	
	$_SESSION["kullanici"]  	= $x["kullanici"];
	$_SESSION["eposta"] 		= $x["eposta"];
	$_SESSION["cinsiyet"] 		= $x["cinsiyet"];
	$_SESSION["fotograf"] 		= $x["fotograf"];
	$_SESSION["sehir"] 			= $x["sehir"];
	$_SESSION["begeni"] 		= $x["begeni"];
	$_SESSION["facebook"] 		= $x["facebook"];
	$_SESSION["twitter"] 		= $x["twitter"];
	$_SESSION["instagram"] 		= $x["instagram"];
	$_SESSION["youtube"] 		= $x["youtube"];
	$_SESSION["onay"] 			= $x["onay"];
	$_SESSION["son_giris"] 		= $x["son_giris"];
	$_SESSION["kayit"] 			= $x["kayit"];
	

			
		header('location: '.$siteurl.'');
		 

}
			
			
		}
			
			
			}
		
		}
	
	
	} } }
?>

</div>

