<?php
ob_start();

include 'conn.php';
include 'head.php';

$nouser = $_GET["nouser"];

if(!$nouser){
	
	header("location: ".$siteurl."");
	
	}
	
		$uyevarmibak = $db->prepare("SELECT * FROM uyeler where kullanici=?");
		$uyevarmibak->execute(array($nouser));
		$uyevarmi = $uyevarmibak->rowCount();
		
		if($uyevarmi >= "1"){header("location: ".$siteurl."user/".$nouser."/confession");}

?><head><title><?php echo $nouser ?> Kullanıcısı Bulunamadı! - <?php echo $sitename ?></title></head>



<div class="covering">

<?php include 'menu.php'; ?>

<div class="cov-a">


<div class="content">

<div class="profile-info shadow">

<div class="no-u-t"><?php echo $nouser ?> isimli kullanıcı bulunamadı!</div>

</div>


<?php include 'footer.php'; ?>

</div>


</div>

</div>

<?php

 ob_end_flush();
 
?>