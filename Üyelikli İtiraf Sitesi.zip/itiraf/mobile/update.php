<?php 

ob_start();
session_start();

	include 'conn.php';
	
	
	$begen = $_GET["like"];
	$emoji = $_GET["e"];
	$ben   = $_SESSION["kullanici"];
	
if($begen){
	
	$itirafuyelercek = $db->prepare("SELECT * FROM begeniler where begenen=? and begenilen_id=?");
	$itirafuyelercek ->execute(array($ben, $begen));
	$begenivarmi = $itirafuyelercek ->rowCount();
	$begeniler2 = $itirafuyelercek->fetch(PDO::FETCH_ASSOC);
	
	
	if($begenivarmi >= "1"){
	
	$guncellebegeni = $db->prepare("update begeniler set emoji=? where id=?");
	$guncellebegeni->execute(array($emoji, $begeniler2["id"]));
			
			if ($guncellebegeni){ 
			
		
		header("location: ".$_SERVER['HTTP_REFERER']."");
			
	}
	
		
	}
		
	
	}






header("location: ".$_SERVER['HTTP_REFERER']."");


ob_end_flush();

?>