<?php 

include 'conn.php';

?><head>
<link href="https://fonts.googleapis.com/css?family=Courgette" rel="stylesheet">
</head>


<style>

.stc-area{width:99%; height:100%; margin:auto; background:#f1f1f1; display:table; border: 1px #ccc solid; border-radius: 5px;}
.box{width: 41%; height: 100px; display: table; margin: auto; background: #fff; border: 1px #dedede solid; border-radius: 5px;}
.box-t{display:table; margin-top:7px; margin-left:5px; float:left;}
.stc-shortcut{width:40%; border-radius:5px; padding:10px; background: #099; margin:auto; margin-top:10px; margin-bottom:10px; display:table; text-align:center; color:#fff;}
.stc-shortcut a{outline:none; text-decoration:none; color:#fff;}
.ptext{width:49%; height:35px; float:left; border:1px #ccc solid; border-radius:5px; padding:10px; margin:3px; margin-bottom:10px;}
.psubmit{width:49%; height:35px; float:left; border:1px #ccc solid; border-radius:5px; background:#FFF; margin:3px;}

@media only screen and (max-width:1550px){
	
body{font-size:40px;}
body a{font-size:40px;}

.stc-area{width:99%;}
.stc-shortcut{width:90%; margin-top:30px; margin-bottom:30px; padding:20px 10px;}

.ptext{width:90%; float:none; margin:auto; margin-top:20px; display:table; padding:40px 10px; font-size:40px;}
.psubmit{width:90%; height:120px; float:none; margin:auto; margin-top:20px; display:table; padding:40px 10px; font-size:40px;}
.box{width:90%; margin-top:30px; margin-bottom:30px; padding:20px 10px;}

.box-t{display:table; margin:auto; float:none; padding:20px 0;}
.box-img{display:table; margin:auto; float:none; padding:20px 0;}

	}

@media only screen and (max-width:1000px){

body{font-size:40px;}
body a{font-size:40px;}

.stc-area{width:99%;}
.stc-shortcut{width:90%; margin-top:30px; margin-bottom:30px; padding:20px 10px;}

.ptext{width:90%; float:none; margin:auto; margin-top:20px; display:table; padding:40px 10px; font-size:40px;}
.psubmit{width:90%; height:120px; float:none; margin:auto; margin-top:20px; display:table; padding:40px 10px; font-size:40px;}
.box{width:90%; margin-top:30px; margin-bottom:30px; padding:20px 10px;}

.box-t{display:table; margin:auto; float:none; padding:20px 0;}
.box-img{display:table; margin:auto; float:none; padding:20px 0;}
	}

@media only screen and (max-width:870px){
	
body{font-size:40px;}
body a{font-size:40px;}

.stc-area{width:99%;}
.stc-shortcut{width:90%; margin-top:30px; margin-bottom:30px; padding:20px 10px;}

.ptext{width:90%; float:none; margin:auto; margin-top:20px; display:table; padding:40px 10px; font-size:40px;}
.psubmit{width:90%; height:120px; float:none; margin:auto; margin-top:20px; display:table; padding:40px 10px; font-size:40px;}
.box{width:90%; margin-top:30px; margin-bottom:30px; padding:20px 10px;}

.box-t{display:table; margin:auto; float:none; padding:20px 0;}
.box-img{display:table; margin:auto; float:none; padding:20px 0;}

	}
	
</style>

<div class="stc-area">

   
<?php 

	$ads = $_POST["adsid"];
	
	if($ads){
	
	$secilenreklam = $db->prepare("SELECT * FROM reklam where kimlik=?");
	$secilenreklam ->execute(array($ads));
	$reklamsay = $secilenreklam ->rowCount();
	$reklam2 = $secilenreklam ->fetch(PDO::FETCH_ASSOC);
	
	if($reklamsay <= "0"){ header("location: ".$_SERVER['HTTP_REFERER'].""); }
	
		?>
    
<div class="stc-shortcut" style="background: bisque; color:#000;">REKLAM İD</div>

     <div class="box" style="height:auto;">
    <div class="box-t"><?php echo $reklam2["id"] ?></div>
    </div>
    
<div class="stc-shortcut" style="background: bisque; color:#000;">REKLAM KİMLİK</div>

     <div class="box" style="height:auto;">
    <div class="box-t"><?php echo $reklam2["kimlik"] ?></div>
    </div>
    
<div class="stc-shortcut" style="background: bisque; color:#000;">REKLAM GÖRÜNTÜLENME</div>

     <div class="box" style="height:auto;">
    <div class="box-t"><?php echo $reklam2["goruntulenme"] ?></div>
    </div>
    
<div class="stc-shortcut" style="background: bisque; color:#000;">REKLAM BAŞLANGIÇ - BİTİŞ TARİHİ</div>

     <div class="box" style="height:auto;">
    <div class="box-t"><?php echo $reklam2["basbit"] ?></div>
    </div>
    
<div class="stc-shortcut" style="background: bisque; color:#000;">REKLAM</div>

    <div class="box" style="height:auto;">
    <div class="box-t" style="margin:5px;"><?php echo $reklam2["reklam"] ?></div>
    </div>
    
    <?php }else{ ?>
    
    <div class="box" style="display:table-cell; vertical-align:middle;">
    
<div class="stc-shortcut" style="font-family: 'Courgette', cursive; font-size:25px;">Reklam İstatistikleri</div>
    
    <form action="" method="post">
    
<div class="stc-shortcut">
<input type="text" name="adsid" placeholder="Reklam Kimliği" class="ptext" title="Reklam Kimliğinizi yazınız" style="border:1px #099 solid; margin:auto; float:none;" maxlength="15" />
</div>

<div class="stc-shortcut">
<input type="submit" style="margin:auto; float:none; background: coral; color:#fff; border:1px coral solid;" class="psubmit" value="Giriş" />
</div>

    </form>
    
    </div>
    
    <?php } ?>

</div>