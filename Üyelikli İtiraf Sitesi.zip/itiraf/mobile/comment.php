<?php

ob_start();
session_start();

	include 'conn.php';
	
	include 'head.php';

?>

<style>

body{margin:0; padding:0; background:#f1f1f1;}

</style>

<?php

$yorumlaricek = $db->prepare("SELECT * FROM yorumlar where yapilan_id=?");
$yorumlaricek ->execute(array($_GET["id"]));
$yorumsay = $yorumlaricek ->rowCount();

?>

<div class="comment-tit" style="font-size:40px;">Yorumlar(<?php echo $yorumsay ?>)</div>

<div class="comment-a" id="com-bot">

<?php

$yorumlar = $yorumlaricek ->fetchAll(PDO::FETCH_ASSOC);
foreach ($yorumlar as $yorum){ 

$yorumuyecek = $db->prepare("SELECT * FROM uyeler where kullanici=?");
$yorumuyecek ->execute(array($yorum["yapan"]));
$yorumuye = $yorumuyecek ->fetch(PDO::FETCH_ASSOC);

?>

<div class="comment-u shadow">

<a href="user/<?php echo $yorum["yapan"] ?>/confession" target="_top"><div class="comment-img" style="background:url(<?php echo $siteurl2.$yorumuye["fotograf"] ?>); background-size:cover; float:none; position:relative;">

<?php if($yorumuye["onay"] == "1"){ ?>
<div class="conf-user" style="position:absolute; bottom: -3px; right: -3px; border: none; background: none; width: auto; height: auto; padding: 0;"><img src="<?php echo $siteurl2 ?>img/icon/approved.png" width="15" height="15" />

</div>
<?php } ?>

</div></a>

<div class="comment" style="float:none;"><?php echo "<a href='user/".$yorum["yapan"]."/confession'><b>".$yorum["yapan"].":</b></a>&nbsp;<font style='color:#777; font-size:30px;'>(".$yorum["tarih"].")</font>&nbsp;".$yorum["yorum"] ?>
&nbsp; <?php if($_SESSION["kullanici"] == $ceo){ echo "<font color='crimson'>".$yorum["id"]."</font>"; } ?>
</div>

<?php if($yorum["yapan"] == $_SESSION["kullanici"] or $yorum["yapilan"] == $_SESSION["kullanici"]){ ?>

<div class="comment-del" style="float:none;  margin:auto; display:table;"><a href="<?php echo $siteurl2 ?>delete.php?comment=<?php echo $yorum["id"] ?>" onclick="return deletecomment()">x</a></div>

<?php } ?>

</div>

<?php } ?>

<?php if($yorumsay <= "0"){ ?>
<div class="comment-tit" style="font-size:40px; background:none; border:none; margin-top:10px;">Hiç yorum yok!</div>
<?php } ?>

</div>

<script type="text/javascript">
var focusBottom = document.getElementById("com-bot");
focusBottom.scrollTop = focusBottom.scrollHeight;
</script>

<div class="send-comment-a">
<?php if($_SESSION){ ?>

<form action="" method="post">


<textarea placeholder="Yorum yaz..." name="go-comment" id="charsy3" onkeyup="TextAreacharactersy3()" style="width:99%; font-size:40px; float:none; margin:auto; display:table;"></textarea>
<input name="send" type="submit" value="Yorum Gönder" style="width:99%; margin:auto; display:table; padding:10px 0; border-radius:5px; background:#099; color:#fff; margin-top:15px; font-size:40px;">
<span id="charactersy3" style="font-size:12px; color:#000; display:table; margin:auto; margin-top:5px;"><?php echo $yorumuzunluk ?></span>


</form>

<?php 

$itiraf = strip_tags(html_entity_decode($_POST["go-comment"]));
$tarih 	= date("d.m.Y");

		$itiraf2cek = $db->prepare("SELECT * FROM itiraf where id=?");
		$itiraf2cek ->execute(array($_GET["id"]));
		$itiraf2 = $itiraf2cek ->fetch(PDO::FETCH_ASSOC);
		
		$aynisivarmisay = $db->prepare("SELECT * FROM yorumlar where yorum=? and yapan=? and yapilan_id=? and tarih=?");
		$aynisivarmisay ->execute(array($itiraf, $_SESSION["kullanici"], $_GET["id"], date("d.m.Y")));
		$aynisivarmi = $aynisivarmisay ->rowCount();
		
		if($_SESSION["kullanici"] == $itiraf2["yazan"]){ $goruldu = "1"; }else{ $goruldu = "0"; }
	
		
if($_POST){
	
	if($aynisivarmi <= "0"){
		
		if($itiraf != ""){

	$kaydetyorum = $db->prepare("insert into yorumlar set yapan=?, yapilan=?, yapilan_id=?, yorum=?, tarih=?, goruldumu=?");
	$kaydetyorum->execute(array($_SESSION["kullanici"], $itiraf2["yazan"], $_GET["id"], $itiraf, $tarih, $goruldu));	
	
	if($kaydetyorum){
		
		header("location: ".$_SERVER['HTTP_REFERER']."");	
	
	}
}

	}
	}

?>
<?php }else{ ?>

<div class="comment-tit" style="font-size:40px; background:none; border:none; padding:24px 0; text-shadow: 1px 1px black;"><a href="login" target="_top" style="color:#099; text-decoration:none; outline:none; font-family: 'Courgette', cursive;">Yorum yapmak için giriş yapmalısın!</a></div>

<?php } ?>

</div>

<?php


if($_SESSION["kullanici"] == $itiraf2["yazan"]){
	$guncellebegeni = $db->prepare("update yorumlar set goruldumu=? where yapilan_id=?");
	$guncellebegeni->execute(array("1", $_GET["id"]));
}


 ob_end_flush(); ?>


