<?php

ob_start();
session_start();

error_reporting(0);

	include '../conn.php';
	
	$email = $_GET["mail"];
	$code  = $_GET["c"];
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include '../head.php'; ?>
<title><?php echo $sitename ?> Şifre Sıfırla</title>
</head>

<body>

<style>

.ibox{width:750px; height:250px; background:#fff; border-radius:5px; display:table;}

</style>

<div class="covering">


<?php include '../menu.php'; ?>

<div class="cov-a">


<div class="content">

<?php 

if($email == "1"){

?>	

	<div class="ibox shadow">
    
    <div style="vertical-align:middle; display:table-cell;">
    
    	<div class="no-conf-t" style="display:table; margin:auto; margin-top:10px;">Şifreni Sıfırlamak İçin E-Posta Adresini Gir!</div>
        
        <form action="" method="post" style="margin: auto; margin-top: auto; display: table; margin-top: 20px;">
        
        <input type="text" class="conf-input" name="mail4" placeholder="E-Posta Adresiniz" />
        
        <input type="submit" class="conf-submit" style="color:#fff;" value="Kod Gönder" />
                
    	</form>

<?php
	    
if ($_POST){
	
	
	$mail2 = $_POST["mail4"];
	$kod1 = rand(444444, 99999999);
	$kod2 = rand(444444, 99999999);
	$kod = $kod1.$kod2;

$birhafta = time()+"604800";

$unutanuye = $db->prepare("SELECT * FROM uyeler WHERE eposta=?");
$unutanuye->execute(array($mail2));
$mailvarmi = $unutanuye->rowCount();

if($mailvarmi <= "0"){
	
	echo "<div class='no-conf-t' style='display:table; margin:auto; margin-top:10px; font-size:16px; color:red'>E-Postayı bulamadık!</div>";
	
	}else{
	
$uyeunuttu = $unutanuye->fetch(PDO::FETCH_ASSOC);
	
$kuladi = $uyeunuttu["kullanici"];
	
	$kaydetkod = $db->prepare("insert into kod set kod=?, kullanici=?, sure=?");
	$kaydetkod->execute(array($kod, $kuladi, $birhafta));	
	
	if($kaydetkod){
		
require("class.phpmailer.php");
$mail = new PHPMailer();
$mail->IsSMTP();
$mail->SMTPDebug = 1; // Hata ayıklama değişkeni: 1 = hata ve mesaj gösterir, 2 = sadece mesaj gösterir
$mail->SMTPAuth = true; //SMTP doğrulama olmalı ve bu değer değişmemeli
$mail->SMTPSecure = 'ssl'; // Normal bağlantı için tls , güvenli bağlantı için ssl yazın
$mail->Host = "mail.itiraf2.com"; // Mail sunucusunun adresi (IP de olabilir)
$mail->Port = 465; // Normal bağlantı için 587, güvenli bağlantı için 465 yazın
$mail->IsHTML(true);
$mail->SetLanguage("tr", "phpmailer/language");
$mail->CharSet  ="utf-8";
$mail->Username = "noreply@itiraf2.com"; // Gönderici adresinizin sunucudaki kullanıcı adı (e-posta adresiniz)
$mail->Password = "şifre"; // Mail adresimizin sifresi
$mail->SetFrom("noreply@itiraf2.com", "$sitename"); // Mail atıldığında gorulecek isim ve email (genelde yukarıdaki username kullanılır)
$mail->AddAddress("$mail2"); // Mailin gönderileceği alıcı adres
$mail->Subject = "$sitename Şifre Sıfırlama"; // Email konu başlığı
$mail->Body = "
            <table id='fv_bodyTable' style='height: 100% !important; margin: 0; padding: 0;	width: 100% !important;	background-color: #fafafa;' align='center' width='100%' height='100%' cellspacing='0' cellpadding='0' border='0'>
                <tbody><tr>
                    <td id='fv_bodyCell' style='height: 100% !important; margin: 0; padding: 0;	width: 100% !important;' align='center' valign='top'>
                        <table id='fv_templateContainer' style='width: 600px; border: 1px solid #ddd; background-color: #fff;' cellspacing='0' cellpadding='0' border='0'>
                            <tbody><tr>
                                <td align='center' valign='top'>
                                    <table id='fv_templateHeader' style='width: 600px; border: 1px solid #ddd; background-color: #fff;' width='100%' cellspacing='0' cellpadding='0' border='0'>
                                        <tbody><tr>
                                            <td class='fv_headerContent' style='background-color: #f8f8f8; border-bottom: 1px solid #ddd; color: #505050; font-family: Helvetica; font-size: 20px; font-weight: 700; line-height: 100%; text-align: left; vertical-align: middle; padding: 0;' valign='top'>
                                                <a href='$siteurl' target='_blank'>
                                                    <img src='$siteurl/img/banner.png' alt='$sitename' width='50' height='50' class='CToWUd' id='fv_headerImage' style='height: auto; max-width: 600px; padding: 20px;'>
                                            </a></td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                            <tr>
                                <td align='center' valign='top'>
                                    <table id='fv_templateBody' style='background-color: #fff;' width='100%' cellspacing='0' cellpadding='0' border='0'>
                                        <tbody><tr>
                                            <td class='fv_bodyContent' style='color: #505050; font-size: 14px; padding: 20px;' valign='top'>
<p>&nbsp;</p>
<p><b>Merhaba $kuladi</b></p><p>Şifrenizi sıfırlamak için aşağıdaki kod'a tıklayabilirsiniz. Kodu kimseyle paylaşmayınız. $sitename ekibi sizden bu kodu istemez.</p><p><b><a href='$siteurl/mail/recover.php?c=1&code=$kod&u=$kuladi'>$kod</a></b></p><p>Kod aktiflik süresi 1 haftadır.</p>
<p>Bunu siz yapmadıysanız hiçbir şey yapmanıza gerek yok, sadece şifrenizin güvenli olduğundan emin olun.</p>
<p>$sitename Türkiye</p></td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                            <tr>
                                <td align='center' valign='top'>
                                    <table id='fv_templateFooter' width='100%' cellspacing='0' cellpadding='0' border='0'>
                                        <tbody><tr>
                                            <td class='fv_footerContent' style='color: grey; font-size: 12px; padding: 20px;' valign='top'>
                                              <p><center>Bu mail'e cevap vermeyiniz<br>
                                                <br>
                                                <center> 
                                                  <p><a href='$siteurl' target='_blank'><font style='color:#333; text-decoration:none;'>$sitename</font></a> <span class='fv_hide-mobile'> | </span>
                                                  <font style='color:#333; text-decoration:none;'>İtiraf paylaş, şehrindeki ya da üniversitendeki itirafları oku!</font><br>
                                                  </p>
                                                </center>
                                                <center>
                                                Copyright © $sitename, Her Hakkı Saklıdır.
                                                </center>
                                              </center>
                                              </p></td>
                                        </tr>
                                    </tbody></table>
                                </td>
                            </tr>
                        </tbody></table>
                    </td>
                </tr>
            </tbody></table>"; // Mailin içeriği
if(!$mail->Send()){
	echo "Email Gönderim Hatasi: ".$mail->ErrorInfo;
} else {
	echo "<div class='no-conf-t' style='display:table; margin:auto; margin-top:10px; font-size:16px; color:#099'>Sana kod gönderdik! E-Postanı kontrol et</div>";
}

}
	
	}
	
	}
		

	?>
        
        </div>
    
    </div>

<?php
	
	}
	
elseif($code == "1"){

?>

<div class="ibox shadow">
    
    <div style="vertical-align:middle; display:table-cell;">
    
    	<div class="no-conf-t" style="display:table; margin:auto; margin-top:10px;">Şifreni Sıfırla!</div>
        
        <form action="" method="post" style="margin: auto; margin-top: auto; display: table; margin-top: 20px;">

<input type="text" class="conf-input" name="user" placeholder="Kullanıcı Adı" style="margin-top: 10px;" maxlength="40" value="<?php echo $_GET["u"]; ?>" required /><br>
<input type="password" class="conf-input" name="fpass" placeholder="Yeni Şifre" style="margin-top: 10px;" maxlength="40" required /><br>
<input type="password" class="conf-input" name="rpass" placeholder="Yeni Şifre" style="margin-top: 10px;" maxlength="40" required /><br>

<input type="submit" class="conf-submit" name="passc" style="color:#fff;" value="Güncelle" />

</form>

<?php 

if ($_POST["passc"]){
	
	$kullanici3 = $_POST["user"];
	$fpass = md5($_POST["fpass"]);
	$rpass = md5($_POST["rpass"]);

	
$kodkullanici6 = $db->prepare("SELECT * FROM kod WHERE kod=?");
$kodkullanici6->execute(array($_GET["code"]));
$kod6 = $kodkullanici6->fetchAll(PDO::FETCH_ASSOC);

foreach ($kod6 as $kodkullanici){
	
$kodkul = $kodkullanici["kullanici"];
	
			
			if($fpass == $rpass and $kullanici3 == $kodkul){
				
$guncellesifre = $db->prepare("update uyeler set sifre=? where kullanici=?"); 
$guncellesifre->execute(array(trim($fpass), $kodkul));

			}else{echo "<div class='no-conf-t' style='display:table; margin:auto; margin-top:10px; font-size:16px; color:red;'>Hata oluştu! <br /> Kullanıcı adı ve kod uyuşmuyor olabilir <br /> Şifreler birbiriyle uyuşmuyor olabilir <br /> Kod aktiflik süresi bitmiş olabilir</div>"; }
			
		if($guncellesifre){ echo "<div class='no-conf-t' style='display:table; margin:auto; margin-top:10px; font-size:16px; color:green;'>Şifre güncellendi!</div>"; 
						  
				$silkod = $db->prepare("delete from kod where kullanici=?");
			    $silkod->execute(array($kodkul));
		
						   
						  }else{ echo "<div class='no-conf-t' style='display:table; margin:auto; margin-top:10px; font-size:16px; color:red ;margin-bottom: 15px;'>Şifre güncellenemedi!</div>"; };
			

		
	}
}

?>

</div>

</div>


<?php
	
	}else{
	
	header("location: ".$siteurl."recover.php?mail=1");
	
	}
	
	?>
    
		

<?php include '../footer.php'; ?>

</div>

</div>

</div>

</body>
</html>

<?php ob_end_flush();  ?>