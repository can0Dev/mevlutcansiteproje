<div class="share-a-confession">

<?php

if($act == "login"){ include 'login.php'; }
elseif($act == "signup"){ include 'signup.php'; }
elseif($_SESSION){ ?>

<div class="siglog-t-a">
<div class="siglog-t">İTİRAF ET</div>
</div>

<form action="" method="post">

<textarea placeholder="İtirafını yaz.." class="conf-textarea" id="charsy2" onkeyup="TextAreacharactersy2()" name="confession" style=" height:75px; margin:auto; display:table; max-width:90%; min-width:90%; width:90%; margin-top:15px; font-size:40px;"></textarea>
<div style="width: 90%; margin:auto; height: 20px; margin-bottom: 3px; margin-top: 5px;">
<span id="charactersy2" style="float:right; font-size:12px; position:relative; color:#fff; font-size:40px; margin-bottom:10px;"><?php echo $itirafuzunluk ?></span>
</div>

<div style="width: 90%; margin:auto; display:table; margin-top: 15px;">

<select class="conf-select" name="city" style="width:45%; margin-bottom:20px; margin-top:-10px;">

	<option selected disabled hidden>Şehir</option>
	<?php 
	
		$sehirlericek = $db->prepare("SELECT * FROM sehirler");
		$sehirlericek->execute(array());
		$sehirleri = $sehirlericek->fetchAll(PDO::FETCH_ASSOC);
		foreach ($sehirleri as $sehirler){ 
	
?>
    
    <option value="<?php echo $sehirler["sehir"] ?>"><?php echo $sehirler["sehir"] ?></option>

<?php } ?>
	</select>
    
    <select class="conf-select" name="university11" style="width:45%; margin-bottom:20px; margin-top:-10px;">

	<option selected disabled hidden>Üniversite</option>
	<?php 
	
		$universitelericek = $db->prepare("SELECT * FROM universite");
		$universitelericek->execute(array());
		$universiteleri = $universitelericek->fetchAll(PDO::FETCH_ASSOC);
		foreach ($universiteleri as $universiteler){ 
	
?>
    
    <option value="<?php echo $universiteler["universite"] ?>"><?php echo $universiteler["universite"] ?></option>

<?php } ?>
	</select>
    
    </div>

<div class="conf-back-a">

<div style="margin:auto; display:table;">

<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/1.jpg);"><input type="radio" name="background" value="1.jpg" checked></div>
<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/2.jpg);"><input type="radio" name="background" value="2.jpg"></div>
<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/3.jpg);"><input type="radio" name="background" value="3.jpg"></div>
<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/4.jpg);"><input type="radio" name="background" value="4.jpg"></div>
<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/5.jpg);"><input type="radio" name="background" value="5.jpg"></div>

</div>

<div style="margin:auto; display:table;">

<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/6.jpg);"><input type="radio" name="background" value="6.jpg"></div>
<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/7.jpg);"><input type="radio" name="background" value="7.jpg"></div>
<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/8.jpg);"><input type="radio" name="background" value="8.jpg"></div>
<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/9.jpg);"><input type="radio" name="background" value="9.jpg"></div>
<div class="conf-back" style="background:url(<?php echo $siteurl2 ?>img/background/10.jpg);"><input type="radio" name="background" value="10.jpg"></div>

</div>

</div>

<div style="margin:auto; display:table;">

<input type="submit" class="conf-submit" style="width:570px;" value="Paylaş" />

</div>

</form>

<?php

$itiraf     = strip_tags(html_entity_decode($_POST["confession"]));
$sehir 	    = strip_tags(html_entity_decode($_POST["city"]));
$universite11 = strip_tags(html_entity_decode($_POST["university11"]));
$arkaplan   = strip_tags(html_entity_decode($_POST["background"]));

if($_SESSION["kullanici"] == "reklam"){$reklamok = "1";}else{$reklamok = "0";}

if($_POST){
	
		$aynisivarmisay2 = $db->prepare("SELECT * FROM itiraf where itiraf=? and yazan=? and tarih=?");
		$aynisivarmisay2 ->execute(array($itiraf, $_SESSION["kullanici"], date("d.m.Y")));
		$aynisivarmi2 = $aynisivarmisay2 ->rowCount();
	
	if($itiraf != ""){
		
			if($aynisivarmi2 <= "0"){
		
			if($universite11 != ""){
	
	
	$itirafpaylas = $db->prepare("insert into itiraf set yazan=?, itiraf=?, sehir=?, universite=?, arkaplan=?, tarih=?, saat=?, reklam=?");
	$itirafpaylas->execute(array($_SESSION["kullanici"], $itiraf, "", $universite11, $arkaplan, date("d.m.Y"), time(), $reklamok));	

			}else{
				
	$itirafpaylas = $db->prepare("insert into itiraf set yazan=?, itiraf=?, sehir=?, universite=?, arkaplan=?, tarih=?, saat=?, reklam=?");
	$itirafpaylas->execute(array($_SESSION["kullanici"], $itiraf, $sehir, "", $arkaplan, date("d.m.Y"), time(), $reklamok));	
				
				}
		

	if($itirafpaylas){
		
		echo '<body onLoad="closenouser()"><div id="nolog-1" style="background:green; padding:5px; text-align: center; margin-top: -15px; color:#fff; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; font-size:40px;">İtiraf Paylaşıldı!</div></body>';
		
		}else{
			
			echo '<body onLoad="closenouser()"><div id="nolog-1" style="background:red; padding:5px; text-align: center; margin-top: -15px; color:#fff; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; font-size:40px;">İtiraf Paylaşılamadı!</div></body>';
			
			}
			
			}else{
				
			echo '<body onLoad="closenouser()"><div id="nolog-1" style="background:blue; padding:5px; text-align: center; margin-top: -15px; color:#fff; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px; font-size:40px;">İtirafı Bugün Paylaştın!</div></body>';
								
					}	
			
			}else{
				
				echo '<body onLoad="closenouser()"><div id="nolog-1" style="background:red; padding:5px; text-align: center; margin-top: -15px; color:#fff; border-bottom-left-radius: 5px; border-bottom-right-radius: 5px;">İtiraf Boş!</div></body>';
				
				}	
			
			}
	
?>

<?php }else{ ?>

<div class="center tx-shadow" style="font-size:54px; color:white; font-family: 'Courgette', cursive;">İtiraf paylaşmak için üye girişi yap</div>

<div class="center tx-shadow" style="font-size:44px; color:white; padding:5px; margin-top:-10px; font-family: 'Courgette', cursive;">Hesabın yoksa 10 saniyede hesap oluştur</div>

<div class="center">

<div class="signup" style="font-family: 'Courgette', cursive;"><a href="signup">Kayıt Ol</a></div>

<div class="login" style="font-family: 'Courgette', cursive;"><a href="login">Giriş Yap</a></div>

</div>

<?php } ?>


</div>