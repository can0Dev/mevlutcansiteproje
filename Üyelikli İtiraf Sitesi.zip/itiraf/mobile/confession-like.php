<?php

ob_start();
session_start();

	include 'conn.php';

	include 'head.php';

$itiraflaricek = $db->prepare("SELECT * FROM itiraf where id=?");
$itiraflaricek ->execute(array($_GET["id"]));
$itiraflar = $itiraflaricek ->fetchAll(PDO::FETCH_ASSOC);
foreach ($itiraflar as $itiraf){ 

$itirafuyelercek = $db->prepare("SELECT * FROM uyeler where kullanici=?");
$itirafuyelercek ->execute(array($itiraf["yazan"]));
$uyeler = $itirafuyelercek ->fetchAll(PDO::FETCH_ASSOC);
foreach ($uyeler as $uye){ 

include 'emoji-list.php';

$itirafbegenilercek = $db->prepare("SELECT * FROM begeniler where begenen=? and begenilen_id=?");
$itirafbegenilercek ->execute(array($_SESSION["kullanici"], $itiraf["id"]));
$itirafbegeni = $itirafbegenilercek ->fetch(PDO::FETCH_ASSOC);

?>

<style>
body{margin:0; padding:0;}
</style>


<div class="emoji-a center" style="padding:0; <?php if ($iphone || $ipod == true){ echo 'width:100% !important;'; }?> ">

<?php if($_GET["nouser"] == "1"){ 

	
?>     
    
<body onLoad="closenouser()">


<div id="nolog-1" style="width:100%; height:155px; background:#333; opacity:0.6; position:absolute;"></div>

<div id="nolog-2" style="width:100%; color:white; text-align:center; font-family: 'Courgette', cursive; font-size: 35px;  position:absolute; top:35px;">İfade bırakmak için üye girişi yapmalısın</div>


</body>
 <?php } ?>

<div class="emoji" style="margin-left:0;">


<div class="center">
<a href="<?php if($itirafbegeni){ if($itirafbegeni["emoji"] == "1"){ ?>delete<?php }elseif($itirafbegeni["emoji"] != "1"){ ?>update<?php } }else{ ?>insert<?php } ?>.php?like=<?php echo $itiraf["id"]; ?>&e=1">
<img src="<?php echo $siteurl2; ?>img/emoji/heart.png" width="40" height="40" />
</a>
</div>

<div class="e-hov-a center" <?php if($itirafbegeni["emoji"] == "1"){ ?> style="background:chocolate;" <?php } ?>>
<div class="e-hov-u" <?php if($itirafbegeni["emoji"] == "1"){ ?> style="background:chocolate;" <?php } ?>></div>
<?php echo $kalpbegeni ?>
</div>

</div>

<div class="emoji" style="margin-left:0;">

<div class="center">
<a href="<?php if($itirafbegeni){ if($itirafbegeni["emoji"] == "2"){ ?>delete<?php }elseif($itirafbegeni["emoji"] != "2"){ ?>update<?php } }else{ ?>insert<?php } ?>.php?like=<?php echo $itiraf["id"]; ?>&e=2">
<img src="<?php echo $siteurl2; ?>img/emoji/smile.png" width="40" height="40" />
</a>
</div>

<div class="e-hov-a center" <?php if($itirafbegeni["emoji"] == "2"){ ?> style="background:chocolate;" <?php } ?>>
<div class="e-hov-u" <?php if($itirafbegeni["emoji"] == "2"){ ?> style="background:chocolate;" <?php } ?>></div>
<?php echo $gulenbegeni ?>
</div>

</div>



<div class="emoji" style="margin-left:0;">


<div class="center">
<a href="<?php if($itirafbegeni){ if($itirafbegeni["emoji"] == "3"){ ?>delete<?php }elseif($itirafbegeni["emoji"] != "3"){ ?>update<?php } }else{ ?>insert<?php } ?>.php?like=<?php echo $itiraf["id"]; ?>&e=3">
<img src="<?php echo $siteurl2; ?>img/emoji/angry.png" width="40" height="40" />
</a>
</div>

<div class="e-hov-a center" <?php if($itirafbegeni["emoji"] == "3"){ ?> style="background:chocolate;" <?php } ?>>
<div class="e-hov-u" <?php if($itirafbegeni["emoji"] == "3"){ ?> style="background:chocolate;" <?php } ?>></div>
<?php echo $sinirlibegeni ?>
</div>

</div>


<div class="emoji" style="margin-left:0;">


<div class="center">
<a href="<?php if($itirafbegeni){ if($itirafbegeni["emoji"] == "4"){ ?>delete<?php }elseif($itirafbegeni["emoji"] != "4"){ ?>update<?php } }else{ ?>insert<?php } ?>.php?like=<?php echo $itiraf["id"]; ?>&e=4">
<img src="<?php echo $siteurl2; ?>img/emoji/sad.png" width="40" height="40" />
</a>
</div>

<div class="e-hov-a center" <?php if($itirafbegeni["emoji"] == "4"){ ?> style="background:chocolate;" <?php } ?>>
<div class="e-hov-u" <?php if($itirafbegeni["emoji"] == "4"){ ?> style="background:chocolate;" <?php } ?>></div>
<?php echo $uzgunbegeni ?>
</div>

</div>


<div class="emoji" style="margin-left:0;">


<div class="center">
<a href="<?php if($itirafbegeni){ if($itirafbegeni["emoji"] == "5"){ ?>delete<?php }elseif($itirafbegeni["emoji"] != "5"){ ?>update<?php } }else{ ?>insert<?php } ?>.php?like=<?php echo $itiraf["id"]; ?>&e=5">
<img src="<?php echo $siteurl2; ?>img/emoji/confused.png" width="40" height="40" />
</a>
</div>

<div class="e-hov-a center" <?php if($itirafbegeni["emoji"] == "5"){ ?> style="background:chocolate;" <?php } ?>>
<div class="e-hov-u" <?php if($itirafbegeni["emoji"] == "5"){ ?> style="background:chocolate;" <?php } ?>></div>
<?php echo $saskinbegeni ?>
</div>

</div>

<div class="emoji">

<div class="center">
<a href="co/<?php echo $itiraf["id"] ?>" target="_top">
<img src="<?php echo $siteurl2; ?>img/emoji/comment.png" width="40" height="40" />
</a>
</div>
<div class="e-hov-a center">
<div class="e-hov-u"></div>
<?php echo $itirafyorum ?>
</div>

</div>


</div>


<?php } } 


ob_end_flush();

?>


