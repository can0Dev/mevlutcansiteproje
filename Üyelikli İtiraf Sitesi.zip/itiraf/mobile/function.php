<script type="text/javascript">
    function TextAreacharactersy2()
    {
        var sonSayi = <?php echo $itirafuzunluk ?> - document.getElementById("charsy2").value.length;
        if (sonSayi >= 0)
        {
            document.getElementById("charactersy2").innerHTML = sonSayi;
        }
        else
        {
            document.getElementById("charsy2").value = document.getElementById("charsy2").value.substring(0, <?php echo $itirafuzunluk ?>);
            document.getElementById("charactersy2").innerHTML = 0;
        }
    }
</script>

<script type="text/javascript">
        function closenouser() {
            
			setTimeout("document.getElementById('nolog-1').style.opacity = '0.5'",  4950);
			setTimeout("document.getElementById('nolog-2').style.opacity = '0.5'",  4950);
			
			setTimeout("document.getElementById('nolog-1').style.opacity = '0.4'",  4960);
			setTimeout("document.getElementById('nolog-2').style.opacity = '0.4'",  4960);
			
			setTimeout("document.getElementById('nolog-1').style.opacity = '0.3'",  4970);
			setTimeout("document.getElementById('nolog-2').style.opacity = '0.3'",  4970);
			
			setTimeout("document.getElementById('nolog-1').style.opacity = '0.2'",  4980);
			setTimeout("document.getElementById('nolog-2').style.opacity = '0.2'",  4980);
			
			setTimeout("document.getElementById('nolog-1').style.opacity = '0.1'",  4990);
			setTimeout("document.getElementById('nolog-2').style.opacity = '0.1'",  4990);
						
			setTimeout("document.getElementById('nolog-1').style.display = 'none'",  5000);
			setTimeout("document.getElementById('nolog-2').style.display = 'none'",  5000);
        }
    </script>
    
    <script>
	    function deleteconf()
	    {
	      if (confirm("İtirafını silersen geri alamazsın!"))
	        return true;
	      else
	        return false;
	    }
</script>

<script>
	    function deleteaccount()
	    {
	      if (confirm("Hesabınızı silerseniz tüm verileriniz silinir ve geri alamazsınız!"))
	        return true;
	      else
	        return false;
	    }
</script>

<script>
	    function blockuser()
	    {
	      if (confirm("Kullanıcının paylaştıklarını gizlemek ister misin?"))
	        return true;
	      else
	        return false;
	    }
</script>

<script>
	    function deletecomment()
	    {
	      if (confirm("Yorumu silmek ister misin?"))
	        return true;
	      else
	        return false;
	    }
</script>

<?php

// İp Bulma

function getRealIpAddr()  
{  
    if (!empty($_SERVER['HTTP_CLIENT_IP']))  
    {  
        $ip=$_SERVER['HTTP_CLIENT_IP'];  
    }  
    elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) //Proxy den bağlanıyorsa gerçek IP yi alır.
     
    {  
        $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];  
    }  
    else  
    {  
        $ip=$_SERVER['REMOTE_ADDR'];  
    }  
    return $ip;  
}

?>