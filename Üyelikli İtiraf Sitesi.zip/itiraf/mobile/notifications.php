<?php

ob_start();
session_start();

	include 'conn.php';
	
	include 'head.php';

?>

<style>

body{margin:0; padding:0;}

</style>

<div class="comment-a" id="com-bot" style="height:1155px;">

<?php

$yorumlaricek = $db->prepare("SELECT * FROM yorumlar where yapilan=? and goruldumu=?");
$yorumlaricek ->execute(array($_SESSION["kullanici"], "0"));
$yorumsay = $yorumlaricek ->rowCount();
$yorumlar = $yorumlaricek ->fetchAll(PDO::FETCH_ASSOC);
foreach ($yorumlar as $yorum){ 

$yorumuyecek = $db->prepare("SELECT * FROM uyeler where kullanici=?");
$yorumuyecek ->execute(array($yorum["yapan"]));
$yorumuye = $yorumuyecek ->fetch(PDO::FETCH_ASSOC);

?>

<div class="comment-u shadow">

<a href="user/<?php echo $yorum["yapan"] ?>/confession" target="_top"><div class="comment-img" style="background:url(<?php echo $siteurl2.$yorumuye["fotograf"] ?>); background-size:cover;"></div></a>

<div class="comment"><a href="user/<?php echo $yorum["yapan"] ?>/confession" target="_top" style="outline:none; text-decoration:none; color:#000; font-weight:bold;"><?php echo $yorum["yapan"] ?></a> <a href="co/<?php echo $yorum["yapilan_id"] ?>" style="outline:none; text-decoration:none; color:#000;" target="_top">itirafına yorum yaptı!</a></div>

<?php if($yorum["yapan"] == $_SESSION["kullanici"] or $yorum["yapilan"] == $_SESSION["kullanici"]){ ?>

<?php } ?>

</div>

<?php } ?>

<?php if($yorumsay <= "0"){ ?>
<div class="comment-tit" style="font-size:40px; background:none; border:none; margin-top:10px;">Hiç bildirim yok!</div>
<?php } ?>

</div>


</div>

<?php ob_end_flush(); ?>


