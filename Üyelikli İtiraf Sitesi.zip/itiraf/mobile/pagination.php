<?php 
	if ($toplamsayi <= $itiraflimit){}else{ ?>
    
    <div class="pagination shadow">
    <div style="display:table; margin:auto;">
    
    <?php 

for($i = $page - $gorunensayfa; $i < $page + $gorunensayfa +1; $i++){

   if($i > 0 and $i <= $sayfa_sayisi){

      if($i == $page){

         echo '<div class="sy-a" style="background:coral; cursor:pointer;"><a>'.$i.'</a></div>';

      }else{
		  
if($act){
         echo '<a href="'.$act.'/'.$i.'" style="outline:none; text-decoration:none; color:#fff;"><div class="sy-a">'.$i.'</div></a>';
}
if($sehir){
         echo '<a href="city/'.$sehir.'/'.$i.'" style="outline:none; text-decoration:none; color:#fff;"><div class="sy-a">'.$i.'</div></a>';
}
if($_GET["university"]){
         echo '<a href="university/'.$_GET["university"].'/'.$i.'" style="outline:none; text-decoration:none; color:#fff;"><div class="sy-a">'.$i.'</div></a>';
}
if($upanel == "confession"){
         echo '<a href="user/'.$userp.'/confession/'.$i.'" style="outline:none; text-decoration:none; color:#fff;"><div class="sy-a">'.$i.'</div></a>';
}

      }

   }

}
?>
    </div>
    </div>
	
	<?php }  ?>