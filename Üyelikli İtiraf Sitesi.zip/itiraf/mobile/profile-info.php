<div class="profile-info shadow">

<?php 

		$profiluyecek2 = $db->prepare("SELECT * FROM uyeler where kullanici=?");
		$profiluyecek2->execute(array($userp));
		$profil2 = $profiluyecek2->fetch(PDO::FETCH_ASSOC);

		$itiraflarisay = $db->prepare("SELECT * FROM itiraf where yazan=?");
		$itiraflarisay->execute(array($userp));
		$itirafsay = $itiraflarisay->rowCount();
		
		$bildirimsaycek = $db->prepare("SELECT * FROM yorumlar where yapilan=? and goruldumu=?");
		$bildirimsaycek->execute(array($_SESSION["kullanici"], "0"));
		$bildirimsay = $bildirimsaycek->rowCount();

		include 'profile-emoji.php';		

?>

<div class="p-i-box pcenter">


<div class="p-i-img" style="background:url(<?php echo $siteurl2.$profil2["fotograf"] ?>); background-size:cover;"><a href="<?php echo $siteurl2.$profil2["fotograf"] ?>" target="_blank"><div style="width:200px; height:200px; border-radius:50%;"></div></a></div>


<div class="p-i-t" id="approved"><?php if($profil2["sayfa_adi"] == ""){ echo $profil2["kullanici"]; }else{ echo $profil2["sayfa_adi"]; } if($profil2["onay"] == "1"){ ?> 

<div style="display: table;float: right;margin-left: 5px; position:relative; margin-top:10px;">
<img src="<?php echo $siteurl2; ?>img/icon/approved.png" width="35" height="35" />

<div class="tit-hov" style="left: -112px; bottom: -118px; background:#f1f1f1; color:#000; font-size:40px;">
<div class="e-hov-u" style="background:#f1f1f1;"></div>
Onaylanmış Hesap
</div>
</div>

 <?php } ?></div>
<div class="p-i-t"><?php echo $profil2["cinsiyet"] ?></div>
<div class="p-i-t"><?php if($profil2["sehir"] == ""){echo 'Şehir Belirtilmedi'; }else{ echo $profil2["sehir"]; } ?></div>


<div class="p-i-t">

<?php if($profil2["facebook"] != ""){ ?>

<div class="p-i-s" id="facebook">
<a href="https://www.facebook.com/<?php echo $profil2["facebook"] ?>" target="_blank"><img src="<?php echo $siteurl2; ?>img/social/facebook.png" width="25" height="25" /></a>


</div> 

<?php } ?>

<?php if($profil2["twitter"] != ""){ ?>

<div class="p-i-s" id="twitter">
<a href="https://www.twitter.com/<?php echo $profil2["twitter"] ?>" target="_blank"><img src="<?php echo $siteurl2; ?>img/social/twitter.png" width="25" height="25" /></a>



</div>

<?php } ?>

<?php if($profil2["instagram"] != ""){ ?>

<div class="p-i-s" id="instagram">
<a href="https://www.instagram.com/<?php echo $profil2["instagram"] ?>" target="_blank"><img src="<?php echo $siteurl2; ?>img/social/instagram.png" width="25" height="25" /></a>



</div>

<?php } ?>


<?php if($profil2["youtube"] != ""){ ?>

<div class="p-i-s" id="youtube">
<a href="https://www.youtube.com/<?php echo $profil2["youtube"] ?>" target="_blank"><img src="<?php echo $siteurl2; ?>img/social/youtube.png" width="25" height="25" /></a>



</div>

<?php } ?>

</div>


</div>



<div class="p-i-box pcenter">

<div class="pcenter">

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="<?php echo $siteurl2; ?>img/emoji/heart.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $kalpbegenip ?></div>

</div>

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="<?php echo $siteurl2; ?>img/emoji/smile.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $gulenbegenip ?></div>
</div>

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="<?php echo $siteurl2; ?>img/emoji/angry.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $sinirlibegenip ?></div>
</div>

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="<?php echo $siteurl2; ?>img/emoji/sad.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $uzgunbegenip ?></div>
</div>

<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="<?php echo $siteurl2; ?>img/emoji/confused.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $saskinbegenip ?></div>
</div>


<div class="p-i-i-box">
<div class="p-i-i-box-img"><img src="<?php echo $siteurl2; ?>img/emoji/comment.png" width="25" height="25" /></div>
<div class="p-i-i-box-t p-i-i-box-t2"><?php echo $itirafyorum1 ?></div>
</div>

<?php $toplambegenip = $kalpbegenip+$gulenbegenip+$asikbegenip+$sinirlibegenip+$uzgunbegenip+$saskinbegenip ?>
<div class="p-i-i-box">
<div class="p-i-i-box-t">Toplam İfade: <?php echo $toplambegenip ?></div>
</div>

<div class="p-i-i-box">
<div class="p-i-i-box-t">Toplam İtiraf: <?php echo $itirafsay ?></div>
</div>

</div>

</div>

<?php if($_SESSION["kullanici"] == $userp){ ?>

<div class="p-i-box pcenter" style="height:auto;">

<div class="pcenter">

<div class="userp-panel" style="position:relative; left:unset; top:unset;">

<div class="userp" style="margin-left:0;">
<a href="user/<?php echo $userp ?>/confession"><img src="<?php echo $siteurl2; ?>img/icon/confession.png" width="20" height="20" /></a>


</div>

<div class="userp">
<a href="user/<?php echo $userp ?>/block"><img src="<?php echo $siteurl2; ?>img/icon/block.png" width="20" height="20" /></a>

</div>

<div class="userp" <?php if($bildirimsay >= "1"){ ?>style="background:coral;"<?php } ?>>
<a href="user/<?php echo $userp ?>/notifications"><img src="<?php echo $siteurl2; ?>img/icon/notifications.png" width="20" height="20" /></a>

</div>

<div class="userp" <?php if($profil2["eposta"] == ""){ ?>style="background:coral;"<?php } ?>>
<a href="user/<?php echo $userp ?>/settings"><img src="<?php echo $siteurl2; ?>img/icon/settings.png" width="20" height="20" /></a>

</div>

<?php if($_SESSION["kullanici"] == $ceo){ ?>

<div class="userp">
<a href="<?php echo $siteurl2 ?>ybbe-panel/"><img src="<?php echo $siteurl2; ?>img/icon/panel.png" width="20" height="20" /></a>

</div>

<?php } ?>

<div class="userp">
<a href="logout.php"><img src="<?php echo $siteurl2; ?>img/icon/logout.png" width="20" height="20" /></a>

</div>


</div>

</div>

</div>

</div>

<?php } ?>

</div>

<?php if($_SESSION["kullanici"] == $userp){ ?>

<div class="profile-link shadow"><font color="crimson">Profil Link:</font> <?php echo $siteurl2 ?>user/<?php echo $userp ?></div>

<?php } ?>