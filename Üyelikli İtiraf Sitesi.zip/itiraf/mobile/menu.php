<?php

	$benimbilgiler = $db->prepare("SELECT * FROM uyeler where kullanici=?");
	$benimbilgiler->execute(array($_SESSION["kullanici"]));
	$benim = $benimbilgiler->fetch(PDO::FETCH_ASSOC);
	
	?>
    
<div class="menu-a">

<div class="menu">

<a href="<?php echo $siteurl ?>"><div class="banner">

</div></a>

</div>

</div>