<?php

	$benimbilgiler = $db->prepare("SELECT * FROM uyeler where kullanici=?");
	$benimbilgiler->execute(array($_SESSION["kullanici"]));
	$benim = $benimbilgiler->fetch(PDO::FETCH_ASSOC);
	
	?>
   
    


<?php if(!$_SESSION){ ?>

<div class="submenu-a">

<div class="pcenter">

<a href="fl-ci.php?ci=1" title="Şehir İtirafları"><div class="submenu"><div  style="width: 50px; height: 50px; margin: 5px; background:url(img/icon/city.png); background-size:cover;"></div></div></a>

<a href="fl-ci.php?fl=1" title="Akış"><div class="submenu"><div style="width: 50px; height: 50px; margin: 5px; background:url(img/icon/flow.png); background-size:cover;"></div></div></a>

</div>

</div>

<?php } ?>

