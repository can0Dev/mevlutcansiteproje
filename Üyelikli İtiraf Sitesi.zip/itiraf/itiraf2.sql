-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 14 Oca 2021, 21:03:55
-- Sunucu sürümü: 10.4.17-MariaDB
-- PHP Sürümü: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Veritabanı: `itiraf2`
--

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `ayarlar`
--

CREATE TABLE `ayarlar` (
  `id` int(11) NOT NULL,
  `ceo` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `siteurl` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `sitename` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `itiraf_uzunluk` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `yorum_uzunluk` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `itiraf_gorunen_limit` varchar(4) COLLATE utf8_turkish_ci NOT NULL,
  `instagram` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  `kullanici_sozlesmesi_yazi` text COLLATE utf8_turkish_ci NOT NULL,
  `gizlilik_cerez_yazi` text COLLATE utf8_turkish_ci NOT NULL,
  `site_yasal_yazi` text COLLATE utf8_turkish_ci NOT NULL,
  `reklam_yazi` text COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `ayarlar`
--

INSERT INTO `ayarlar` (`id`, `ceo`, `siteurl`, `sitename`, `itiraf_uzunluk`, `yorum_uzunluk`, `itiraf_gorunen_limit`, `instagram`, `kullanici_sozlesmesi_yazi`, `gizlilik_cerez_yazi`, `site_yasal_yazi`, `reklam_yazi`) VALUES
(1, 'yasinekran', 'https://localhost/itiraf2script/', 'İtiraf2', '3000', '330', '10', 'itiraf2com', '<p><strong style=\"margin-left:25px;\">Kullanıcı Sözleşmesi Nedir?</strong></p>\r\n\r\n<ol>\r\n	<li>Bu koşullar İtiraf2.com, internet sitesi, mobil uygulama ve mobil site üzerinden erişiminizi ve kullanım koşullarını yöneten yasal belgelerin bir kısmıdır.</li>\r\n</ol>\r\n\r\n<p><br />\r\n<strong style=\"margin-left:25px;\">Kullanım Şartları</strong></p>\r\n\r\n<ol>\r\n	<li>İtiraf2.com\'u kullanmak için en az 18 yaşında olmalısınız. Aksi taktirde oluşabilecek tehlikelerden Fevolin sorumlu değildir. 18 yaş altında olduğunuz tespit edilirse hesap kapatma işlemi uygulanır. Ülkenizde reşit olma yaşı farklılık gösterebilir.</li>\r\n	<br />\r\n	<li>Paylaşım hizmetini kullanabilmeniz için üye olmanız şarttır.</li>\r\n    <li>Kullanıcıların itiraf, fotoğraf vb. (İzin verilen değişim hizmetleri) paylaşım veya eklemelerinde zorbalık, pornografik, küfür, rencide etme, tehdit etme gibi tehlikeli bulunan her gönderi kullanıcıya aittir. İtiraf2.com hiçbir sorumluluk üstlenmez.</li>\r\n	<br />\r\n    <li>Uymanız gereken toplum kuralları yukarıdaki kullanım şartları maddesindeki fıkraları kapsamaktadır. Aksi halde uyumsuzluk gösterilirse hesabınız kapatılır.</li>\r\n	<br />\r\n    <li>İtiraf2 ekibine paylaştığım gönderileri instagram, facebook, twitter gibi sosyal platformlarda paylaşmasına izin veriyorum.</li>\r\n	<br />\r\n    <li>Kayıt ol butonuna basıldıktan sonra site kuralları ve kullanıcı sözleşmesini onaylamış sayılırsınız.</li>\r\n	<br />\r\n    <li>İtiraf2.com’a üye olduktan sonra tüm kurallara uymak kullanıcıya aittir. Kayıt ol ve Giriş Yap butonuna tıkladıktan sonra itiraf2.com sadece bilgileri barındırma hizmeti veriyor olacaktır.</li>\r\n	<br />\r\n</ol> \r\n\r\n<p><br />\r\n<strong style=\"margin-left:25px;\">Hesap Gizliliği</strong></p>\r\n\r\n<ol>\r\n	<li>Gizliliğiniz ve güvenliğiniz için kimseye kullanıcı bilgilerinizi vermeyiniz.</li>\r\n	<br />\r\n	<li>İtiraf2.com ekibi sizden hiçbir zaman kullanıcı bilgilerinizi istemez.</li>\r\n	<br />\r\n	<li>Kullanıcı adı değiştirilemez. Fotoraf ve sosyal medya hesap ayarlarınızı değiştirebilirsiniz.</li>\r\n	<br />\r\n	<li>İtiraf2.com Kullanıcıların IP bilgilerini genel bir şekilde Kullanıcıların tanımlanmasını sağlamak ve kapsamlı olarak demografik bilgi toplamak amacıyla kayıt etme hakkına sahiptir.</li>\r\n	<br />\r\n	<li>İtiraf2.com Web Sitesi, işbu Kullanım Koşulları ve Gizlilik Bildirimi’nde aksi belirtilmediği sürece toplanan kullanıcı bilgilerini yalnızca kendi iş akışı için kullanmayı, üçüncü kişilerle paylaşmamayı ve herhangi bir kuruluş ya da şirkete satmamayı kabul, beyan ve taahhüt eder.</li>\r\n	<br />\r\n    <li>İtiraf2.com kurallarda değişim hakkını gizli tutar.</li>\r\n</ol>\r\n\r\n<p><br />\r\n<strong style=\"margin-left:25px;\">Hesap Silme</strong></p>\r\n\r\n<ol>\r\n	<li>Kayıt olduktan sonra hesabınızı silmeyi ayarlardan aktif edemezsiniz.</li>\r\n	<br />\r\n	<li>fotoğrafınızı ve kişisel bilgilerinizi kaldırabilirsiniz.</li>\r\n	<br />\r\n	<li>Son giriş tarihiniz 1 ay öncesindeyse hesabınızın görünürlüğü kapatılacak eğer 1 sene ve üzerindeyse hesabınız otomatik olarak silinecektir.</li>\r\n	<br />\r\n	<li>Hesap silindikten sonra itiraflarınız, kişisel bilgileriniz, fotoğrafınız ve beğenilerinizde silinir.</li>\r\n	<br />\r\n	<li>Hesap silindikten sonra tekrar yeni hesap açılabilir. Fakat diğer silinen hesaptan hiçbir şey transfer edilemez.</li>\r\n    <br />\r\n    <li>İtiraf2.com\'a kayıt ol butonuna tıkladıktan sonra kabul etmiş sayılırsınız.</li>\r\n	<br />\r\n    <li>İtiraf2.com kurallarda değişim hakkını gizli tutar.</li>\r\n</ol>', '<p><strong style=\"margin-left:25px;\">Gizlilik</strong></p>\r\n\r\n<ol>\r\n	<li>İtiraf2.com, Kullanıcıların IP bilgilerini genel bir şekilde Kullanıcıların tanımlanmasını sağlamak ve kapsamlı olarak demografik bilgi toplamak amacıyla kayıt etme hakkına sahiptir.</li>\r\n	<br />\r\n	<li>İtiraf2.com, işbu Kullanım Koşulları ve Gizlilik Bildirimi’nde aksi belirtilmediği sürece toplanan kullanıcı bilgilerini yalnızca kendi iş akışı için kullanmayı, üçüncü kişilerle paylaşmamayı ve herhangi bir kuruluş ya da şirkete satmamayı kabul, beyan ve taahhüt eder.</li>\r\n	<br />\r\n	<li>Reklamlarda daha önceden ziyaret ettiğiniz sayfa bilgileriniz kullanılabilir detaylı bilgi için aşağıdaki <strong>Reklamlar</strong> maddesine göz atınız.</li>\r\n	<br />\r\n	<li>İtiraf2.com kurallarda değişim hakkını gizli tutar ve site içerisinde kullanıcı kaynaklı sorunların hiçbirinde sorumluluk kabul etmez.</li>\r\n</ol>\r\n\r\n<p><br />\r\n<strong style=\"margin-left:25px;\">Çerezler - Cookie</strong></p>\r\n\r\n<ol>\r\n	<li>Çerez olarak adlandırılan ve kullanıcıyı tanımlamaya yardımcı olan yazılımı yerleştirebilir. Cookie kullanımı, İtiraf2.com ziyaretlerinde ve internet üzerinde standart bir politika olarak kabul edilen uygulamadır.</li>\r\n	<br />\r\n	<li>Kullanıcılar istekleri doğrultusunda işlevsel kullanım amacıyla yerleştirilecek Cookie\'leri kişisel web tarayıcı ayarları sayesinde engelleyebilme haklarını saklı tutarlar.</li>\r\n</ol>\r\n\r\n<p><br />\r\n<strong style=\"margin-left:25px;\">Reklamlar</strong></p>\r\n\r\n<ol>\r\n	<li>Kişiselleştirilmiş reklamları kullanmaktayız ve reklam veren sizin ilgi alanı, demografi ve diğer kriterlerinize ulaşır. Reklam teknolojisi sağlayıcıları, kişiselleştirilmiş reklamlarda kullanıcılara ait kişisel verileri toplayabildikleri, alabildikleri ve kullanabildikleri için, kişisel verilerin reklam kişiselleştirme amacıyla toplanması, paylaşılması ve kullanılmasına yönelik izninizi almaktayız. Sitemizi kullanıyorsanız ve kullanmaya devam ederseniz kabul etmiş sayılırsınız.</li>\r\n	<br />\r\n	<li>Google dahil üçüncü taraf sağlayıcılar, kullanıcıların web sitenize yaptığı önceki ziyaretlere dayalı olarak reklam yayınlamak üzere çerezleri kullanmaktadır.</li>\r\n	<br />\r\n	<li>Google\'ın DoubleClick çerezlerini kullanması, kendisinin ve iş ortaklarının, sitenize ve/veya İnternet\'teki diğer sitelere yaptıkları ziyaretlere dayalı olarak kullanıcılarınıza reklam sunmasına olanak tanır.</li>\r\n	<br />\r\n	<li>Kullanıcılar, Reklam Ayarlarını ziyaret ederek ilgi alanına dayalı reklamcılık için DoubleClick çerezi kullanımını devre dışı bırakabilir.</li>\r\n	<br />\r\n	<li>(Alternatif olarak, kullanıcıları aboutads.info adresini ziyaret ederek, ilgi alanına dayalı reklamcılık için bir üçüncü taraf sağlayıcının çerez kullanımını devre dışı bırakmaya yönlendirebilirsiniz.)</li>\r\n</ol>\r\n', '<ol>\r\n	<li>İtiraf2.com kullanıcı sözleşmesi, gizlilik ve çerezler konularında bilgilendirme yapmış olup değişiklik hakkını gizli tutacağını belirtmiştir.</li>\r\n	<br />\r\n	<li>İtiraf2.com ekibi toplum kurallarını önemser ve istenmeyen paylaşımlarda bulunursanız hesabınız inceleme altına alınabilir.</li>\r\n	<br />\r\n	<li>İtiraf2.com ekibi incelemeler sonucunda hesabınızı silmeye karar verir ve yetkisi vardır.</li>\r\n	<br />\r\n	<li>Her kullanıcı paylaştığından kendi sorumludur, doğabilecek sorunlarda İtiraf2.com ve ekibi sorumlu tutulamaz.</li>\r\n	<br />\r\n	<li>İtiraf2.com içerisinde zorbalık, aşağılama, pornografik içerik, din, ırk, mezhep farkından hakarat, konularında işi ciddiye alarak hesaplarınızı inceleme altına alır.</li>\r\n    <br />\r\n    <li>Yukarıdaki maddede gözden kaçan paylaşımlar olursa siz paylaşımı yapmış kişiyi gizleyerek diğer paylaşımlarını kapatabilirsiniz.</li>\r\n	<br />\r\n    <li>İtiraf2.com Site yasal hakları yukarıda belirtilmiştir. İtiraf2\'yi kullanmaya (websitesi, mobil uygulama, mobil site vb.) başlar veya devam ederseniz kuralları ve sözleşmeyi kabul etmiş sayılırsınız.</li>\r\n</ol>', '<ol>\r\n	<li>İtiraf2.com sitesinde paylaşılmış itiraflar arasında reklamınızın yerini alın.</li>\r\n	<br />\r\n	<li>Günlük, haftalık, aylık seçenekleriyle reklamınızı paylaşın</li>\r\n	<br />\r\n	<li>Size verilen reklam kimlik numarası ile istatistiklerinizi görüntüleyin.</li>\r\n	<br />\r\n	<li>Paylaşılan itirafların arasında görünen reklamlarla kullanıcının dikkatini çekin, geri dönüş sağlayın.</li>\r\n    <br />\r\n	<li>İletişim için <a href=\"https://www.instagram.com/itiraf2com\" target=\"_blank\" style=\"color: #517fa4; text-decoration:none; font-family: \'Lobster\', cursive;\">İnstagram</a></li>\r\n</ol>\r\n\r\n<img src=\"https://www.itiraf2.com/img/ads-pub.png\" style=\"margin-left:20px;\" width=\"700\" height=\"350\" />');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `begeniler`
--

CREATE TABLE `begeniler` (
  `id` int(11) NOT NULL,
  `begenen` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `begenilen` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `begenilen_id` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `emoji` varchar(1) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `begeniler`
--

INSERT INTO `begeniler` (`id`, `begenen`, `begenilen`, `begenilen_id`, `emoji`) VALUES
(1, 'bengukbrs', 'busracik', '1', '3'),
(2, 'anonbayan', 'busracik', '1', '2'),
(3, 'anonbayan', 'anonbayan', '2', '2'),
(4, 'busracik', 'busracik', '1', '2'),
(5, 'busracik', 'anonbayan', '2', '2'),
(6, 'deryablr', 'busracik', '1', '5'),
(7, 'deryablr', 'anonbayan', '2', '6'),
(8, 'suley-man', 'suley-man', '3', '2'),
(9, 'suley-man', 'busracik', '1', '2'),
(10, 'suley-man', 'anonbayan', '2', '3'),
(12, 'yasinekran', 'anonbayan', '2', '2'),
(13, 'yasinekran', 'busracik', '1', '1'),
(14, 'anonbayan', 'suley-man', '3', '2'),
(15, 'busracik', 'suley-man', '3', '2'),
(16, 'deryablr', 'suley-man', '3', '2'),
(17, 'buketbuket', 'busracik', '1', '3'),
(18, 'buketbuket', 'suley-man', '3', '6'),
(19, 'buketbuket', 'anonbayan', '2', '2'),
(20, 'begumiz', 'anonbayan', '2', '1'),
(21, 'begumiz', 'suley-man', '3', '6'),
(22, 'begumiz', 'busracik', '1', '2'),
(23, 'suley-man', 'suley-man', '4', '2'),
(24, 'anonbayan', 'suley-man', '4', '4'),
(25, 'busracik', 'suley-man', '4', '3'),
(26, 'buketbuket', 'suley-man', '4', '2'),
(27, 'begumiz', 'suley-man', '4', '6'),
(28, 'yasinekran', 'suley-man', '4', '2'),
(29, 'anonbayan', 'anonbayan', '5', '2'),
(30, 'anonbayan', 'anonbayan', '6', '2'),
(31, 'suley-man', 'anonbayan', '6', '2'),
(32, 'yasinekran', 'anonbayan', '6', '2'),
(33, 'yasinekran', 'anonbayan', '5', '2'),
(34, 'anonbayan', 'anonbayan', '7', '2'),
(35, 'yasinekran', 'anonbayan', '7', '2'),
(36, 'eypoffcl', 'suley-man', '3', '2'),
(37, 'yasinekran', 'gebzeitirafediyor', '8', '1'),
(38, 'anonbayan', 'gebzeitirafediyor', '8', '1'),
(39, 'gebzeitirafediyor', 'gebzeitirafediyor', '8', '1'),
(40, 'yasinekran', 'suley-man', '3', '2'),
(43, 'busracik', 'emocan', '10', '2'),
(44, 'yasinekran', 'emocan', '10', '2'),
(45, 'onurtilki', 'emocan', '10', '1'),
(46, 'yasinekran', 'emocan', '13', '1'),
(50, 'anonbayan', 'anonbayan', '21', '1'),
(51, 'emocan', 'aliriza', '14', '2'),
(52, 'emocan', 'emocan', '22', '1'),
(53, 'abbaov', 'anonbayan', '2', '2'),
(54, 'abbaov', 'suley-man', '3', '4'),
(55, 'abbaov', 'anonbayan', '7', '2'),
(56, 'abbaov', 'busracik', '1', '1'),
(57, 'yasinekran', 'sounde', '23', '1'),
(58, 'abbaov', 'anonbayan', '24', '2'),
(59, 'anonbayan', 'anonbayan', '25', '1'),
(60, 'yasinekran', 'anonbayan', '25', '1');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `engel`
--

CREATE TABLE `engel` (
  `id` int(11) NOT NULL,
  `engelleyen` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `engellenen` varchar(20) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `itiraf`
--

CREATE TABLE `itiraf` (
  `id` int(11) NOT NULL,
  `yazan` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `itiraf` text COLLATE utf8_turkish_ci NOT NULL,
  `sehir` varchar(25) COLLATE utf8_turkish_ci NOT NULL,
  `universite` varchar(200) COLLATE utf8_turkish_ci NOT NULL,
  `arkaplan` varchar(15) COLLATE utf8_turkish_ci NOT NULL,
  `tarih` varchar(10) COLLATE utf8_turkish_ci NOT NULL,
  `saat` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `reklam` varchar(2) COLLATE utf8_turkish_ci NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `itiraf`
--

INSERT INTO `itiraf` (`id`, `yazan`, `itiraf`, `sehir`, `universite`, `arkaplan`, `tarih`, `saat`, `reklam`) VALUES
(1, 'busracik', 'Bir aleyna olamadım ama sende benim düşmeye doyamadığım dipsiz kuyumdun', 'Çanakkale', '', '3.jpg', '09.09.2018', '1536485754', '0'),
(2, 'anonbayan', 'İlk yemeğe çıkışımızda cep telefonum çalmıştı. Elimi çantama attım. Kurcaladım, kurcaladım yok. Telefonda uzun uzun çalmaya devam ediyor. Bir türlü bulamadım. Sonra o güzel cümle döküldü dudaklarımdan: \'Evde mi bıraktım acaba?\' ne utanmıştım ya!', 'Aydın', '', '1.jpg', '09.09.2018', '1536491609', '0'),
(3, 'suley-man', 'Birgün gece üçte oturduğum sitedeki kızla mesajlaşıyorum. Biranda Alsancağa gidelim diye fikir ortaya attım o da gidelim dedi. Alsancağa vardık takılıyoruz takribi 20 dakika falan zaman geçti tam sigara yaktık birtane cd bir abimiz çırılçıplak koşarak yanımıza geldi kafada peruk, makyajlar yapılmış, önde itafiye hortumu... \r\nGençler kusura bakmayın çakmağınızı kullanabilir miyim dedi kibarca bende uzattım yanımdaki kız kafasını denize çevirdi. Yan tarafta balıkçı bir abi vardı kafası güzel gel güzelim ben çakarım sana dedi. Ulan bir küfürler uçuştu hafada sonra balıkçıya daldı abimiz. Kız kaçmaya başladı bende arkasından koşuyorum. Kaçtığımızı fark edince arkadan bize bağırmaya başladı hop gençler hop falan ulan ne tırstım kaçıyorum neyse bir döndüm arkama baktım yetişmiş bana. Dediği laf şu çakmağını unuttun. ulan kızın yanında façayıda bozduk o mesajlaşmada attığım fikirin ta amına koyayım.', 'İzmir', '', '9.jpg', '10.09.2018', '1536577346', '0'),
(5, 'anonbayan', 'Dün kız arkadaşımla İzmir fuarındaydık konserler falan derken kanka bune yine biz hariç herkes öpüşüyor dedi neyse yemek falan yedik sonra tuvalete  gittik duyduğumuz sesler ahey ahey... Bunada şükür kanka dediğini hatırlar gibiyim.', 'İzmir', '', '4.jpg', '10.09.2018', '1536590553', '0'),
(6, 'anonbayan', 'Evleneceğim kişiyle olurda erkek çocuk haberi alırsak ve isim düşünme safhasında ısrarla babasının demode ismini koymaya çalışırsa vazgeçirmek için, o ismin eski sevgilimin adı olduğunu söylicem. Bırak o ismi babasından bile bahsetmez.', 'Aydın', '', '7.jpg', '11.09.2018', '1536648890', '0'),
(7, 'anonbayan', 'Ben hiçbir zaman bu kadar abazayı bir arada görmemiştim. Teşekkürler Ribony...', 'Aydın', '', '6.jpg', '11.09.2018', '1536682992', '0'),
(8, 'gebzeitirafediyor', 'Herkese Merhabalar!', 'Kocaeli', '', '1.jpg', '12.09.2018', '1536756688', '0'),
(10, 'emocan', 'kırbacımı kimde unuttum bilmiyorum...', '', '', '1.jpg', '14.09.2018', '1536940303', '0'),
(13, 'emocan', 'sevgilim olur musun ?.  k. adı: SELENA', 'İzmir', '', '1.jpg', '15.09.2018', '1537025608', '0'),
(14, 'aliriza', 'Afyon iibfde zeytin kafede gördüğüm sarışın uzun boylu üstünde kırmızı tişört ve siyah çantası vardı bana ulaş ', '', 'Afyon Kocatepe Üniversitesi', '1.jpg', '16.09.2018', '1537096057', '0'),
(21, 'anonbayan', 'Nazilli Osmanlı Kahvecisinde 2. katta grupça oturan beyefendiler, baktığınızı çakmadık devam edin utanmaya gerek yok :D', '', 'Adnan Menderes Üniversitesi', '7.jpg', '17.09.2018', '1537192440', '0'),
(22, 'emocan', 'seni ilk gördüğüm günü hatırlıyor musun?', 'İzmir', '', '1.jpg', '17.09.2018', '1537204293', '0'),
(23, 'sounde', 'dünyaya gülerek gelen varmıki zaten agladık hepimiz', '', '', '10.jpg', '20.09.2018', '1537445155', '0'),
(24, 'anonbayan', 'Yaşım 19 sormayın artık!!!!', '', '', '6.jpg', '20.09.2018', '1537445500', '0'),
(25, 'anonbayan', 'Adünün taş hatununu açıklıyorum... Gizemmm :D :D', '', 'Adnan Menderes Üniversitesi', '3.jpg', '21.09.2018', '1537530352', '0');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `kod`
--

CREATE TABLE `kod` (
  `id` int(11) NOT NULL,
  `kod` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `kullanici` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `sure` varchar(75) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `reklam`
--

CREATE TABLE `reklam` (
  `id` int(11) NOT NULL,
  `konum` varchar(10) COLLATE utf8_turkish_ci NOT NULL,
  `kimlik` varchar(15) COLLATE utf8_turkish_ci NOT NULL,
  `reklam` text COLLATE utf8_turkish_ci NOT NULL,
  `goruntulenme` varchar(11) COLLATE utf8_turkish_ci NOT NULL DEFAULT '0',
  `basbit` varchar(23) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `reklam`
--

INSERT INTO `reklam` (`id`, `konum`, `kimlik`, `reklam`, `goruntulenme`, `basbit`) VALUES
(1, 'sol', '', '', '', ''),
(2, 'sag', '', '', '', ''),
(3, 'telefon', '', '', '', ''),
(6, 'orta', '', '', '0', '05.09.2018 - 12.01.2020'),
(7, 'orta', '', '', '1', '05.09.2018 - 12.01.2020');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sehirler`
--

CREATE TABLE `sehirler` (
  `id` int(11) NOT NULL,
  `sehir` varchar(25) COLLATE utf8_turkish_ci NOT NULL,
  `seo` varchar(25) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `sehirler`
--

INSERT INTO `sehirler` (`id`, `sehir`, `seo`) VALUES
(1, 'Adana', 'adana'),
(2, 'Adıyaman', 'adiyaman'),
(3, 'Afyonkarahisar', 'afyonkarahisar'),
(4, 'Ağrı', 'agri'),
(5, 'Amasya', 'amasya'),
(6, 'Ankara', 'ankara'),
(7, 'Antalya', 'antalya'),
(8, 'Artvin', 'artvin'),
(9, 'Aydın', 'aydin'),
(10, 'Balıkesir', 'balikesir'),
(11, 'Bilecik', 'bilecik'),
(12, 'Bingöl', 'bingol'),
(13, 'Bitlis', 'bitlis'),
(14, 'Bolu', 'bolu'),
(15, 'Burdur', 'burdur'),
(16, 'Bursa', 'bursa'),
(17, 'Çanakkale', 'canakkale'),
(18, 'Çankırı', 'cankiri'),
(19, 'Çorum', 'corum'),
(20, 'Denizli', 'denizli'),
(21, 'Diyarbakır', 'diyarbakir'),
(22, 'Edirne', 'edirne'),
(23, 'Elazığ', 'elazig'),
(24, 'Erzincan', 'erzincan'),
(25, 'Erzurum', 'erzurum'),
(26, 'Eskişehir', 'eskisehir'),
(27, 'Gaziantep', 'gaziantep'),
(28, 'Giresun', 'giresun'),
(29, 'Gümüşhane', 'gumushane'),
(30, 'Hakkari', 'hakkari'),
(31, 'Hatay', 'hatay'),
(32, 'Isparta', 'isparta'),
(33, 'Mersin', 'mersin'),
(34, 'İstanbul', 'istanbul'),
(35, 'İzmir', 'izmir'),
(36, 'Kars', 'kars'),
(37, 'Kastamonu', 'kastamonu'),
(38, 'Kayseri', 'kayseri'),
(39, 'Kırklareli', 'kirklareli'),
(40, 'Kırşehir', 'kirsehir'),
(41, 'Kocaeli', 'kocaeli'),
(42, 'Konya', 'konya'),
(43, 'Kütahya', 'kutahya'),
(44, 'Malatya', 'malatya'),
(45, 'Manisa', 'manisa'),
(46, 'Kahramanmaraş', 'kahramanmaras'),
(47, 'Mardin', 'mardin'),
(48, 'Muğla', 'mugla'),
(49, 'Muş', 'mus'),
(50, 'Nevşehir', 'nevsehir'),
(51, 'Niğde', 'nigde'),
(52, 'Ordu', 'ordu'),
(53, 'Rize', 'rize'),
(54, 'Sakarya', 'sakarya'),
(55, 'Samsun', 'samsun'),
(56, 'Siirt', 'siirt'),
(57, 'Sinop', 'sinop'),
(58, 'Sivas', 'sivas'),
(59, 'Tekirdağ', 'tekirdag'),
(60, 'Tokat', 'tokat'),
(61, 'Trabzon', 'trabzon'),
(62, 'Tunceli', 'tunceli'),
(63, 'Şanlıurfa', 'sanliurfa'),
(64, 'Uşak', 'usak'),
(65, 'Van', 'van'),
(66, 'Yozgat', 'yozgat'),
(67, 'Zonguldak', 'zonguldak'),
(68, 'Aksaray', 'aksaray'),
(69, 'Bayburt', 'bayburt'),
(70, 'Karaman', 'karaman'),
(71, 'Kırıkkale', 'kirikkale'),
(72, 'Batman', 'batman'),
(73, 'Şırnak', 'sirnak'),
(74, 'Bartın', 'bartin'),
(75, 'Ardahan', 'ardahan'),
(76, 'Iğdır', 'igdir'),
(77, 'Yalova', 'yalova'),
(78, 'Karabük', 'karabuk'),
(79, 'Kilis', 'kilis'),
(80, 'Osmaniye', 'osmaniye'),
(81, 'Düzce', 'duzce');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `universite`
--

CREATE TABLE `universite` (
  `id` int(11) NOT NULL,
  `seo` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `universite` varchar(100) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `universite`
--

INSERT INTO `universite` (`id`, `seo`, `universite`) VALUES
(1, 'adana-bilim-ve-teknoloji-universitesi', 'Adana Bilim ve Teknoloji Üniversitesi'),
(2, 'cukurova-universitesi', 'Çukurova Üniversitesi'),
(3, 'iskendurun-universitesi', 'İskendurun Üniversitesi'),
(4, 'adiyaman-universitesi', 'Adıyaman Üniversitesi'),
(5, 'afyon-kocatepe-universitesi', 'Afyon Kocatepe Üniversitesi'),
(6, 'agri-ibrahim-cecen-universitesi', 'Ağrı İbrahim Çeçen Üniversitesi'),
(7, 'aksaray-universitesi', 'Aksaray Üniversitesi'),
(8, 'amasya-universitesi', 'Amasya Üniversitesi'),
(9, 'anka-teknoloji-universitesi', 'Anka Teknoloji Üniversitesi'),
(10, 'atilim-universitesi', 'Atılım Üniversitesi'),
(11, 'baskent-universitesi', 'Başkent Üniversitesi'),
(12, 'cankaya-universitesi', 'Çankaya Üniversitesi'),
(13, 'ihsan-dogramaci-bilkent-universitesi', 'İhsan Doğramacı Bilkent Üniversitesi'),
(14, 'ted-universitesi', 'Ted Üniversitesi'),
(15, 'tobb-ekonomi-ve-teknoloji-universitesi', 'Tobb Ekonomi ve Teknoloji Üniversitesi'),
(16, 'turk-hava-kurumu-universitesi', 'Türk Hava Kurumu Üniversitesi'),
(17, 'ufuk-universitesi', 'Ufuk Üniversitesi'),
(18, 'yuksek-ihtisas-universitesi', 'Yüksek İhtisas Üniversitesi'),
(19, 'ankara-sosyal-bilimler-universitesi', 'Ankara Sosyal Bilimler Üniversitesi'),
(20, 'ankara-universitesi', 'Ankara Üniversitesi'),
(21, 'ankara-yildirim-beyazit-universitesi', 'Ankara Yıldırım Beyazıt Üniversitesi'),
(22, 'gazi-universitesi', 'Gazi Üniversitesi'),
(23, 'hacettepe-universitesi', 'Hacettepe Üniversitesi'),
(24, 'orta-dogu-teknik-universitesi', 'Orta Doğu Teknik Üniversitesi'),
(25, 'alanya-hamdullah-emin-pasa-universitesi', 'Alanya Hamdullah Emin Paşa Üniversitesi'),
(26, 'antalya-akev-universitesi', 'Antalya Akev Üniversitesi'),
(27, 'uluslararasi-antalya-universitesi', 'Uluslararası Antalya Üniversitesi'),
(28, 'akdeniz-universitesi', 'Akdeniz Üniversitesi'),
(29, 'alanya-alaaddin-keykubat-universitesi', 'Alanya Alaaddin Keykubat Üniversitesi'),
(30, 'artvin-coruh-universitesi', 'Artvin Çoruh Üniversitesi'),
(31, 'adnan-mendere-universitesi', 'Adnan Menderes Üniversitesi'),
(32, 'balikesir-universitesi', 'Balıkesir Üniversitesi'),
(33, 'bartin-universitesi', 'Bartın Üniversitesi'),
(34, 'batman-universitesi', 'Batman Üniversitesi'),
(35, 'bayburt-universitesi', 'Bayburt Üniversitesi'),
(36, 'bilecik-seyh-edebali-universitesi', 'Bilecik Şeyh Edebali Üniversitesi'),
(37, 'bingol-universitesi', 'Bingöl Üniversitesi'),
(38, 'bitlis-eren-universitesi', 'Bitlis Eren Üniversitesi'),
(39, 'abant-izzet-baysal-universitesi', 'Abant İzzet Baysal Üniversitesi'),
(40, 'mehmet-akif-ersoy-universitesi', 'Mehmet Akif Ersoy Üniversitesi'),
(41, 'bursa-teknik-universitesi', 'Bursa Teknik Üniversitesi'),
(42, 'uludag-universitesi', 'Uludağ Üniversitesi'),
(43, 'canakkale-onsekiz-mart-universitesi', 'Çanakkale Onsekiz Mart Üniversitesi'),
(44, 'cankiri-karatekin-universitesi', 'Çankırı Karatekin Üniversitesi'),
(45, 'hitit-universitesi', 'Hitit Üniversitesi'),
(46, 'pamukkale-universitesi', 'Pamukkale Üniversitesi'),
(47, 'dicle-universitesi', 'Dicle Üniversitesi'),
(48, 'duzce-universitesi', 'Düzce Üniversitesi'),
(49, 'trakya-universitesi', 'Trakya Üniversitesi'),
(50, 'firat-universitesi', 'Fırat Üniversitesi'),
(51, 'erzincan-universitesi', 'Erzincan Üniversitesi'),
(52, 'ataturk-universitesi', 'Atatürk Üniversitesi'),
(53, 'erzurum-teknik-universitesi', 'Erzurum Teknik Üniversitesi'),
(54, 'anadolu-universitesi', 'Anadolu Üniversitesi'),
(55, 'eskisehir-osmangazi-universitesi', 'Eskişehir Osmangazi Üniversitesi'),
(56, 'hasan-kalyoncu-universitesi', 'Hasan Kalyoncu Üniversitesi'),
(57, 'sanko-universitesi', 'Sanko Üniversitesi'),
(58, 'gaziantep-universitesi', 'Gaziantep Üniversitesi'),
(59, 'kilis-7-aralik-universitesi', 'Kilis 7 Aralık Üniversitesi'),
(60, 'giresun-universitesi', 'Giresun Üniversitesi'),
(61, 'gumushane-universitesi', 'Gümüşhane Üniversitesi'),
(62, 'hakkari-universitesi', 'Hakkari Üniversitesi'),
(63, 'mustafa-kemal-universitesi', 'Mustafa Kemal Üniversitesi'),
(64, 'igdir-universitesi', 'Iğdır Üniversitesi'),
(65, 'suleyman-demirel-universitesi', 'Süleyman Demirel Üniversitesi'),
(66, 'acibadem-universitesi', 'Acıbadem Üniversitesi'),
(67, 'bahcesehir-universitesi', 'Bahçeşehir Üniversitesi'),
(68, 'beykent-universitesi', 'Beyken Üniversitesi'),
(69, 'beykoz-universitesi', 'Beykoz Üniversitesi'),
(70, 'bezm-i-alem-vakif-universitesi', 'Bezm-i Alem Üniversitesi'),
(71, 'biruni-universitesi', 'Biruni Üniversitesi'),
(72, 'dogus-universitesi', 'Doğuş Üniversitesi'),
(73, 'fatih-sultan-mehmet-vakif-universitesi', 'Fatih Sultan Mehmet Vakıf Üniversitesi'),
(74, 'fenerbahce-universitesi', 'Fenerbahçe Üniversitesi'),
(75, 'halic-universitesi', 'Haliç Üniversitesi'),
(76, 'isik-universitesi', 'Işık Üniversitesi'),
(77, 'ibn-haldun-universitesi', 'İbn Haldun Üniversitesi'),
(78, 'istanbul-arel-universitesi', 'İstanbul Arel Üniversitesi'),
(79, 'istanbul-aydin-universitesi', 'İstanbul Aydın Üniversitesi'),
(80, 'istanbul-ayvansaray-universitesi', 'İstanbul Ayvansaray Üniversitesi'),
(81, 'istanbul bilgi universitesi', 'İstanbul Bilgi Üniversitesi'),
(82, 'istanbul-bilim-universitesi', 'İstanbul Bilim Üniversitesi'),
(83, 'istanbul-esenyurt-universitesi', 'İstanbul Esenyurt Üniversitesi'),
(84, 'istanbul-gedik-universitesi', 'İstanbul Gedik Üniversitesi'),
(85, 'istanbul-gelisim-universitesi', 'İstanbul Gelişim Üniversitesi'),
(86, 'istanbul-kemerburgaz-universitesi', 'İstanbul Kemerburgaz Üniversitesi'),
(87, 'istanbul-kent-universitesi', 'İstanbul Kent Üniversitesi'),
(88, 'istanbul-kultur-universitesi', 'İstanbul Kültür Üniversitesi'),
(89, 'istanbul-medipol-universitesi', 'İstanbul Medipol Üniversitesi'),
(90, 'istanbul-rumeli-universitesi', 'İstanbul Rumeli Üniversitesi'),
(91, 'istanbul-sabahattin-zaim-universitesi', 'İstanbul Sabahattin Zaim Üniversitesi'),
(92, 'istanbul-sehir-universitesi', 'İstanbul Şehir Üniversitesi'),
(93, 'istanbul-ticaret-universitesi', 'İstanbul Ticaret Üniversitesi'),
(94, 'istanbul-yeni-yuzyil-universitesi', 'İstanbul Yeni Yüzyıl Üniversitesi'),
(95, 'istanbul-29-mayıs-universitesi', 'İstanbuk 29 Mayıs Üniversitesi'),
(96, 'istinye-universitesi', 'İstinye Üniversitesi'),
(97, 'kadir-has-universitesi', 'Kadir Has Üniversitesi'),
(98, 'koc-universitesi', 'Koç Üniversitesi'),
(99, 'maltepe-universitesi', 'Maltepe Üniversitesi'),
(100, 'mef-universitesi', 'Mef Üniversitesi'),
(101, 'nisantasi-universitesi', 'Nişantaşı Üniversitesi'),
(102, 'okan-universitesi', 'Okan Üniversitesi'),
(103, 'ozyegin-universitesi', 'Özyeğin Üniversitesi'),
(104, 'piri-reis-universitesi', 'Piri Reis Üniversitesi'),
(105, 'sabanci-universitesi', 'Sabancı Üniversitesi'),
(106, 'uskudar-universitesi', 'Üsküdar Üniversitesi'),
(107, 'yasar-universitesi', 'Yaşar Üniversitesi'),
(108, 'yeditepe-universitesi', 'Yeditepe Üniversitesi'),
(109, 'atasehir-adiguzel-meslek-yuksekokulu', 'Ataşehir Adıgüzel Meslek Yüksekokulu'),
(110, 'avrupa-meslek-yuksekokulu', 'Avrupa Meslek Yüksekokulu'),
(111, 'faruk-sarac-tasarim-meslek-yuksekokulu', 'Faruk Saraç Tasarım Meslek Yüksekokulu'),
(112, 'istanbul-kavram-meslek-yuksekokulu', 'İstanbul Kavram Meslek Yüksekokulu'),
(113, 'istanbul-sisli-meslek-yuksekokulu', 'İstanbul Şişli Meslek Yüksekokulu'),
(114, 'bogazici-universitesi', 'Boğaziçi Üniversitesi'),
(115, 'galatasaray-universitesi', 'Galatasaray Üniversitesi'),
(116, 'istanbul-medeniyet-universitesi', 'İstanbul Medeniyet Üniversitesi'),
(117, 'istanbul-teknik-universitesi', 'İstanbul Teknik Üniversitesi'),
(118, 'istanbul-universitesi', 'İstanbul Üniversitesi'),
(119, 'marmara-universitesi', 'Marmara Üniversitesi'),
(120, 'milli-savunma-universitesi', 'Milli Savunma Üniversitesi'),
(121, 'mimar-sinan-guzel-sanatlar-universitesi', 'Mimar Sinan Güzel Sanatlar Üniversitesi'),
(122, 'saglik-bilimleri-universitesi', 'Sağlık Bilimleri Üniversitesi'),
(123, 'turk-alman-universitesi', 'Türk-Alman Üniversitesi'),
(124, 'turkiye-uluslararasi-islam-bilim-ve-teknoloji-universitesi', 'Türkiye Uluslar Arası İslam, Bilim ve Teknoloji Üniversitesi'),
(125, 'yildiz-teknik-universitesi', 'Yıldız Teknik Üniversitesi'),
(126, 'izmir-ekonomi-universitesi', 'İzmir Ekonomi Üniversitesi'),
(127, 'dokuz-eylul-universitesi', 'Dokuz Eylül Üniversitesi'),
(128, 'ege-universitesi', 'Ege Üniversitesi'),
(129, 'izmir-bakircay-universitesi', 'İzmir Bakırçay Üniversitesi'),
(130, 'izmir-demokrasi-universitesi', 'İzmir Demokrasi Üniversitesi'),
(131, 'izmir-katip-celebi-universitesi', 'İzmir Katip Çelebi Üniversitesi'),
(132, 'izmir-yuksek-teknoloji-enstitusu', 'İzmir Yüksek Teknoloji Enstitüsü'),
(133, 'kahramanmaras-sutcu-imam-universitesi', 'Kahramanmaraş Sütçü İmam Üniversitesi'),
(134, 'karabuk-universitesi', 'Karabük Üniversitesi'),
(135, 'karamanoglu-mehmetbey-universitesi', 'Karamanoğlu Mehmetbey Üniversitesi'),
(136, 'kafkas-universitesi', 'Kafkas Üniversitesi'),
(137, 'kastamonu-universitesi', 'Kastamonu Üniversitesi'),
(138, 'nuh-naci-yazgan-universitesi', 'Nuh Naci Yazgan Üniversitesi'),
(139, 'abdullah-gul-universitesi', 'Abdullah Gül Üniversitesi'),
(140, 'erciyes-universitesi', 'Erciyes Üniversitesi'),
(141, 'kirikkale-universitesi', 'Kırıkkale Üniversitesi'),
(142, 'ahi-evran-universitesi', 'Ahi Evran Üniversitesi'),
(143, 'gebze-teknik-universitesi', 'Gebze Teknik Üniversitesi'),
(144, 'kocaeli-universitesi', 'Kocaeli Üniversitesi'),
(145, 'konya-gida-ve-tarim-universitesi', 'Konya Gıda ve Tarım Üniversitesi'),
(146, 'kto-karatay-universitesi', 'Kto Karatay Üniversitesi'),
(147, 'necmettin-erbakan-universitesi', 'Necmettin Erbakan Üniversitesi'),
(148, 'selcuk-universitesi', 'Selçuk Üniversitesi'),
(149, 'dumlupinar-universitesi', 'Dumlupınar Üniversitesi'),
(150, 'inonu-universitesi', 'İnönü Üniversitesi'),
(151, 'manisa-celal-bayar-universitesi', 'Manisa Celal Bayar Üniversitesi'),
(152, 'mardin-artuklu-universitesi', 'Mardin Artuklu Üniversitesi'),
(153, 'cag-universitesi', 'Çağ Üniversitesi'),
(154, 'toros-universitesi', 'Toros Üniversitesi'),
(155, 'mersin-universitesi', 'Mersin Üniversitesi'),
(156, 'mugla-sitki-kocman-universitesi', 'Muğla Sıtkı Koçman Üniversitesi'),
(157, 'mus-alparslan-universitesi', 'Muş Alparslan Üniversitesi'),
(158, 'kapadokya-meslek-yuksekokulu', 'Kapadokya Meslek Yüksekokulu'),
(159, 'nevsehir-haci-bektas-veli-universitesi', 'Nevşehir Hacı Bektaş Veli Üniversitesi'),
(160, 'omer-halisdemir-universitesi', 'Ömer Halisdemir Üniversitesi'),
(161, 'ordu-universitesi', 'Ordu Üniversitesi'),
(162, 'osmaniye-korkut-ata-universitesi', 'Osmaniye Korkut Ata Üniversitesi'),
(163, 'recep-tayyip-erdogan-universitesi', 'Recep Tayyip Erdoğan Üniversitesi'),
(164, 'sakarya-universitesi', 'Sakarya Üniversitesi'),
(165, 'bandırma-onyedi-eylul-universitesi', 'Bandırma Onyedi Eylül Üniversitesi'),
(166, 'ondukoz-mayis-universitesi', 'Ondukuz Mayıs Üniversitesi'),
(167, 'siirt-universitesi', 'Siirt Üniversitesi'),
(168, 'sinop-universitesi', 'Sinop Üniversitesi'),
(169, 'cumhuriyet-universitesi', 'Cumhuriyet Üniversitesi'),
(170, 'harran-universitesi', 'Harran Üniversitesi'),
(171, 'sirnak-universitesi', 'Şırnak Üniversitesi'),
(172, 'namik-kemal-universitesi', 'Namık Kemal Üniversitesi'),
(173, 'gaziosmanpasa-universitesi', 'Gaziosmanpaşa Üniversitesi'),
(174, 'avrasya-universitesi', 'Avrasya Üniversitesi'),
(175, 'karadeniz-tenik-universitesi', 'Karadeniz Teknik Üniversitesi'),
(176, 'munzur-universitesi', 'Munzur Üniversitesi'),
(177, 'usak-universitesi', 'Uşak Üniversitesi'),
(178, 'yuzuncu-yil-universitesi', 'Yüzüncü Yıl Üniversitesi'),
(179, 'yalova-universitesi', 'Yalova Üniversitesi'),
(180, 'bozok-universitesi', 'Bozok Üniversitesi'),
(181, 'bulent-ecevit-universitesi', 'Bülent Ecevit Üniversitesi');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `uyeler`
--

CREATE TABLE `uyeler` (
  `id` int(11) NOT NULL,
  `kullanici` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `sifre` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `sayfa_adi` varchar(100) COLLATE utf8_turkish_ci NOT NULL,
  `eposta` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `cinsiyet` varchar(12) COLLATE utf8_turkish_ci NOT NULL,
  `fotograf` varchar(220) COLLATE utf8_turkish_ci NOT NULL DEFAULT 'img/no-photo.png',
  `sehir` varchar(25) COLLATE utf8_turkish_ci NOT NULL,
  `begeni` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `facebook` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  `twitter` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  `instagram` varchar(30) COLLATE utf8_turkish_ci NOT NULL,
  `youtube` varchar(75) COLLATE utf8_turkish_ci NOT NULL,
  `onay` varchar(2) COLLATE utf8_turkish_ci NOT NULL DEFAULT '0',
  `son_giris` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `kayit` varchar(10) COLLATE utf8_turkish_ci NOT NULL,
  `ipadres` varchar(30) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `uyeler`
--

INSERT INTO `uyeler` (`id`, `kullanici`, `sifre`, `sayfa_adi`, `eposta`, `cinsiyet`, `fotograf`, `sehir`, `begeni`, `facebook`, `twitter`, `instagram`, `youtube`, `onay`, `son_giris`, `kayit`, `ipadres`) VALUES
(1, 'yasinekran', '469d66af00baf2ecc995ebff6bb72da0', '', '', 'Erkek', 'img/no-photo.png', 'İzmir', '0', 'ekranyasin', 'yasinekran', 'yasinekran', '', '0', '2036325829', '07.09.2018', ''),
(2, 'reklam', '469d66af00baf2ecc995ebff6bb72da0', '', '', 'Erkek', 'img/no-photo.png', '', '', '', '', '', '', '1', '2036325829', '07.09.2018', ''),
(3, 'mervesu', '', '', '', 'Kadın', 'img/no-photo.png', '', '1', '', '', '', '', '0', '1536350976', '07.09.2018', ''),
(4, 'sevgicikk', '', '', '', 'Kadın', 'img/no-photo.png', '', '1', '', '', '', '', '0', '1536368415', '08.09.2018', ''),
(5, 'busracik', '', '', '', 'Kadın', 'img/no-photo.png', '', '9', '', '', '', '', '0', '1537126665', '09.09.2018', ''),
(6, 'buketbuket', '', '', '', 'Kadın', 'img/no-photo.png', '', '', '', '', '', '', '0', '1536586201', '09.09.2018', ''),
(7, 'bengukbrs', '', '', '', 'Kadın', 'img/no-photo.png', '', '', '', '', '', '', '0', '1536485883', '09.09.2018', ''),
(8, 'deryablr', '', '', '', 'Kadın', 'img/no-photo.png', '', '', '', '', '', '', '0', '1536578104', '09.09.2018', ''),
(9, 'begumiz', '', '', '', 'Kadın', 'img/no-photo.png', 'İzmir', '', '', '', '', '', '0', '1536940237', '09.09.2018', ''),
(11, 'anonbayan', '', '', '', 'Kadın', 'img/no-photo.png', '', '20', '', '', '', '', '0', '1537530352', '09.09.2018', ''),
(12, 'ozankulhan', '', '', '', 'Erkek', 'img/no-photo.png', '', '', '', '', '', '', '0', '1537451512', '09.09.2018', ''),
(13, 'suley-man', '', '', '', 'Erkek', 'img/no-photo.png', '', '15', '', '', '', '', '0', '1537091859', '10.09.2018', ''),
(14, 'itirafnoktasi', '', '', '', 'Erkek', 'img/no-photo.png', '', '', '', '', '', '', '0', '1536681782', '11.09.2018', ''),
(15, 'Esrarengiz', '', '', '', '', 'img/no-photo.png', '', '', '', '', '', '', '0', '1536687085', '11.09.2018', ''),
(16, 'owomoyela', '', '', '', 'Erkek', 'img/no-photo.png', '', '', '', '', '', '', '0', '1536740608', '12.09.2018', ''),
(17, 'eypoffcl', '', '', '', 'Erkek', 'img/no-photo.png', '', '', '', '', '', '', '0', '1536747364', '12.09.2018', ''),
(18, 'gebzeitirafediyor', '', '', '', 'Erkek', 'img/no-photo.png', '', '3', '', '', '', '', '1', '1536765586', '12.09.2018', ''),
(26, 'emocan', '', '', '', 'Erkek', 'img/no-photo.png', '', '7', '', '', '', '', '0', '1537204726', '14.09.2018', ''),
(27, 'onurtilki', '', '', '', 'Erkek', 'img/no-photo.png', '', '', '', '', '', '', '0', '1537035493', '15.09.2018', ''),
(28, 'aliriza', '', '', '', 'Erkek', 'img/no-photo.png', '', '1', '', '', '', '', '0', '1537096086', '16.09.2018', ''),
(29, 'abbaov', '', '', '', 'Erkek', 'img/no-photo.png', '', '', '', '', '', '', '0', '1537464884', '20.09.2018', ''),
(30, 'sounde', '', '', '', 'Erkek', 'img/no-photo.png', '', '1', '', '', '', '', '0', '1537445171', '20.09.2018', '');

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `yorumlar`
--

CREATE TABLE `yorumlar` (
  `id` int(11) NOT NULL,
  `yapan` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `yapilan` varchar(20) COLLATE utf8_turkish_ci NOT NULL,
  `yapilan_id` varchar(11) COLLATE utf8_turkish_ci NOT NULL,
  `yorum` text COLLATE utf8_turkish_ci NOT NULL,
  `tarih` varchar(10) COLLATE utf8_turkish_ci NOT NULL,
  `goruldumu` varchar(2) COLLATE utf8_turkish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

--
-- Tablo döküm verisi `yorumlar`
--

INSERT INTO `yorumlar` (`id`, `yapan`, `yapilan`, `yapilan_id`, `yorum`, `tarih`, `goruldumu`) VALUES
(1, 'abbaov', 'anonbayan', '6', 'bence deneme bile..', '20.09.2018', '1');

--
-- Dökümü yapılmış tablolar için indeksler
--

--
-- Tablo için indeksler `ayarlar`
--
ALTER TABLE `ayarlar`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `begeniler`
--
ALTER TABLE `begeniler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `engel`
--
ALTER TABLE `engel`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `itiraf`
--
ALTER TABLE `itiraf`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `kod`
--
ALTER TABLE `kod`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `reklam`
--
ALTER TABLE `reklam`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `sehirler`
--
ALTER TABLE `sehirler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `universite`
--
ALTER TABLE `universite`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `uyeler`
--
ALTER TABLE `uyeler`
  ADD PRIMARY KEY (`id`);

--
-- Tablo için indeksler `yorumlar`
--
ALTER TABLE `yorumlar`
  ADD PRIMARY KEY (`id`);

--
-- Dökümü yapılmış tablolar için AUTO_INCREMENT değeri
--

--
-- Tablo için AUTO_INCREMENT değeri `ayarlar`
--
ALTER TABLE `ayarlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Tablo için AUTO_INCREMENT değeri `begeniler`
--
ALTER TABLE `begeniler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- Tablo için AUTO_INCREMENT değeri `engel`
--
ALTER TABLE `engel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `itiraf`
--
ALTER TABLE `itiraf`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- Tablo için AUTO_INCREMENT değeri `kod`
--
ALTER TABLE `kod`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Tablo için AUTO_INCREMENT değeri `reklam`
--
ALTER TABLE `reklam`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Tablo için AUTO_INCREMENT değeri `sehirler`
--
ALTER TABLE `sehirler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- Tablo için AUTO_INCREMENT değeri `universite`
--
ALTER TABLE `universite`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=182;

--
-- Tablo için AUTO_INCREMENT değeri `uyeler`
--
ALTER TABLE `uyeler`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Tablo için AUTO_INCREMENT değeri `yorumlar`
--
ALTER TABLE `yorumlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
