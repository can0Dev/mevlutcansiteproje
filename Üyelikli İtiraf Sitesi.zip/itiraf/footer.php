<div class="footer shadow" <?php if($act or $sehir){ echo 'style="margin-top:10px;"'; } ?> >
<div style="display:table; margin:auto;">

<div class="footer-t" style="cursor: context-menu;">© <?php echo date("Y"); echo ' '; echo $sitename ?></div>
<div class="footer-t"><a href="page/user-agreement">Kullanıcı Sözleşmesi</a></div>
<div class="footer-t"><a href="page/privacy-and-cookies">Gizlilik ve Çerezler</a></div>
<div class="footer-t"><a href="page/site-legal-rights">Site Yasal Hakları</a></div>
<div class="footer-t"><a href="page/advertisement">Reklam</a></div>

<?php if($instagram != ""){ ?>
<div class="footer-t" style="font-family: 'Lobster', cursive; font-size:15px;"><a href="https://www.instagram.com/<?php echo $instagram ?>" target="_blank" style="color: #517fa4; text-decoration:none;">İnstagram</a></div>
<?php } ?>
Bu script Can Groups tarafından ücretsiz Kodlanmıştır. Satılmaz.
</div>

</div>

