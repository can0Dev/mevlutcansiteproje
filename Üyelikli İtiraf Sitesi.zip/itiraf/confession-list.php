<?php

$simdi 			= time();
$birsaat 		= $simdi-3600;
$birgun 		= $simdi-86400;
$birhafta 		= $simdi-604800;
$profilconf 	= $_GET["pconf"];
$sehir			= $_GET["city"];
$universitelist = $_GET["university"];
$detay			= $_GET["detid"];

if(!$act and !$sehir or !$login or !$signup or !$universitelist){

$itiraflaricek = $db->prepare("SELECT * FROM itiraf order by rand() limit $itiraflimit");
$itiraflaricek ->execute(array());

}

if($sehir){
			
		$sehirlericek2 = $db->prepare("SELECT * FROM sehirler where seo=?");
		$sehirlericek2->execute(array($sehir));
		$sehir2 = $sehirlericek2->fetch(PDO::FETCH_ASSOC);
		

$page  			 = @intval($_GET['page']); if(!$page) $page = "1";
$ilansay  		 = $db->prepare("select * from itiraf where sehir=? order by id desc");
$ilansay         -> execute(array($sehir2["sehir"]));
$toplamsayi  	 = $ilansay->rowCount();
$limit			 = $itiraflimit;
$sayfa_sayisi	 = round($toplamsayi/$limit); if($page > $sayfa_sayisi){$page = 1;}
$goster   		 = $page * $limit - $limit;
$gorunensayfa    = 6;
	
$itiraflaricek = $db->prepare("SELECT * FROM itiraf where sehir=? order by id desc limit $goster,$limit");
$itiraflaricek ->execute(array($sehir2["sehir"]));

}

if($universitelist){
			
		$hmnunicek = $db->prepare("SELECT * FROM universite where seo=?");
		$hmnunicek->execute(array($universitelist));
		$unicek2 = $hmnunicek->fetch(PDO::FETCH_ASSOC);
			
$page  			 = @intval($_GET['page']); if(!$page) $page = "1";
$ilansay  		 = $db->prepare("select * from itiraf where universite=? order by id desc");
$ilansay         -> execute(array($unicek2["universite"]));
$toplamsayi  	 = $ilansay->rowCount();
$limit			 = $itiraflimit;
$sayfa_sayisi	 = round($toplamsayi/$limit); if($page > $sayfa_sayisi){$page = 1;}
$goster   		 = $page * $limit - $limit;
$gorunensayfa    = 6;
	

$itiraflaricek = $db->prepare("SELECT * FROM itiraf where universite=? order by id desc limit $goster,$limit");
$itiraflaricek ->execute(array($unicek2["universite"]));

}

if($act == "flow-now"){
	
$page  			 = @intval($_GET['page']); if(!$page) $page = "1";
$ilansay  		 = $db->prepare("select * from itiraf where saat<=? and saat>=? order by id desc");
$ilansay         -> execute(array($simdi, $birsaat));
$toplamsayi  	 = $ilansay->rowCount();
$limit			 = $itiraflimit;
$sayfa_sayisi	 = round($toplamsayi/$limit); if($page > $sayfa_sayisi){$page = 1;}
$goster   		 = $page * $limit - $limit;
$gorunensayfa    = 6;
	

$itiraflaricek = $db->prepare("SELECT * FROM itiraf where saat<=? and saat>=? order by id desc limit $goster,$limit");
$itiraflaricek ->execute(array($simdi, $birsaat));

}

if($act == "flow-1-hour-ago"){
	
$page  			 = @intval($_GET['page']); if(!$page) $page = "1";
$ilansay  		 = $db->prepare("select * from itiraf where saat<=? and saat>=? order by id desc");
$ilansay         -> execute(array($birsaat, $birgun));
$toplamsayi  	 = $ilansay->rowCount();
$limit			 = $itiraflimit;
$sayfa_sayisi	 = round($toplamsayi/$limit); if($page > $sayfa_sayisi){$page = 1;}
$goster   		 = $page * $limit - $limit;
$gorunensayfa    = 6;
	
$itiraflaricek = $db->prepare("SELECT * FROM itiraf where saat<=? and saat>=? order by id desc limit $goster,$limit");
$itiraflaricek ->execute(array($birsaat, $birgun));

}

if($act == "flow-1-day-ago"){

$page  			 = @intval($_GET['page']); if(!$page) $page = "1";
$ilansay  		 = $db->prepare("select * from itiraf where saat<=? and saat>=? order by id desc");
$ilansay         -> execute(array($birgun, $birhafta));
$toplamsayi  	 = $ilansay->rowCount();
$limit			 = $itiraflimit;
$sayfa_sayisi	 = round($toplamsayi/$limit); if($page > $sayfa_sayisi){$page = 1;}
$goster   		 = $page * $limit - $limit;
$gorunensayfa    = 6;
	
$itiraflaricek = $db->prepare("SELECT * FROM itiraf where saat<=? and saat>=? order by id desc limit $goster,$limit");
$itiraflaricek ->execute(array($birgun, $birhafta));

}

if($act == "flow-1-week-ago"){ 

$page  			 = @intval($_GET['page']); if(!$page) $page = "1";
$ilansay  		 = $db->prepare("select * from itiraf where saat<=? order by id desc");
$ilansay         -> execute(array($birhafta));
$toplamsayi  	 = $ilansay->rowCount();
$limit			 = $itiraflimit;
$sayfa_sayisi	 = round($toplamsayi/$limit); if($page > $sayfa_sayisi){$page = 1;}
$goster   		 = $page * $limit - $limit;
$gorunensayfa    = 6;
	
$itiraflaricek = $db->prepare("SELECT * FROM itiraf where saat<=? order by id desc limit $goster,$limit");
$itiraflaricek ->execute(array($birhafta));

}


if($upanel == "confession"){ 

$page  			 = @intval($_GET['page']); if(!$page) $page = "1";
$ilansay  		 = $db->prepare("select * from itiraf where yazan=? order by id desc");
$ilansay         -> execute(array($userp));
$toplamsayi  	 = $ilansay->rowCount();
$limit			 = $itiraflimit;
$sayfa_sayisi	 = round($toplamsayi/$limit); if($page > $sayfa_sayisi){$page = 1;}
$goster   		 = $page * $limit - $limit;
$gorunensayfa    = 6;

$itiraflaricek = $db->prepare("SELECT * FROM itiraf where yazan=? order by id desc limit $goster,$limit");
$itiraflaricek ->execute(array($userp));

}

if($detay){
			
$itiraflaricek = $db->prepare("SELECT * FROM itiraf where id=?");
$itiraflaricek ->execute(array($detay));

}

?>
