<?php 

	include 'conn.php';


//REKLAM EKLEME

$reklambul = array('','İzmir','İstanbul','Ankara','Adana', 'Antalya', 'Bursa', 'Çanakkale', 'Eskişehir', 'Konya');
$reklamsehir2 = array_rand($reklambul,1);

    if($reklamsehir2 == "0"){$reklamsehir = "";}
elseif($reklamsehir2 == "1"){$reklamsehir = "İzmir";}
elseif($reklamsehir2 == "2"){$reklamsehir = "İstanbul";}
elseif($reklamsehir2 == "3"){$reklamsehir = "Ankara";}
elseif($reklamsehir2 == "4"){$reklamsehir = "Adana";}
elseif($reklamsehir2 == "5"){$reklamsehir = "Antalya";}
elseif($reklamsehir2 == "6"){$reklamsehir = "Bursa";}
elseif($reklamsehir2 == "7"){$reklamsehir = "Çanakkale";}
elseif($reklamsehir2 == "8"){$reklamsehir = "Eskişehir";}
elseif($reklamsehir2 == "9"){$reklamsehir = "Konya";}
	
	$reklampaylas = $db->prepare("insert into itiraf set yazan=?, reklam=?, tarih=?, saat=?, sehir=?");
	$reklampaylas->execute(array("reklam", "1", date("d.m.Y"), time(), $reklamsehir));	
	
	
//ŞİFREMİ UNUTTUM SÜRESİ DOLAN KODLARI SİLME



?>