<?php

ob_start();
session_start();

	include 'conn.php';
	
	$userp 		= $_GET["user"];
	$upanel		= $_GET["u"];
	
	if(!$upanel){header("location: ".$userp."/".$upanel."confession"."");}
	
		$uyevarmibak = $db->prepare("SELECT * FROM uyeler where kullanici=?");
		$uyevarmibak->execute(array($userp));
		$uyevarmi = $uyevarmibak->rowCount();
		
		if($uyevarmi <= "0"){header("location: ".$siteurl."no-user.php?nouser=".$userp."");}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<?php include 'head.php'; ?>
<?php if($upanel == "confession"){ ?> <title><?php echo $userp." - ".$sitename ?></title> <?php } ?>
<?php if($upanel == "block"){ ?> <title>Gizlediğin Kullanıcılar - <?php echo $sitename ?></title> <?php } ?>
<?php if($upanel == "notifications"){ ?> <title>Bildirimler - <?php echo $sitename ?></title> <?php } ?>
<?php if($upanel == "settings"){ ?> <title>Hesap Ayarları - <?php echo $sitename ?></title> <?php } ?>

</head>

<body>

<?php

	if ($iphone || $android || $palmpre || $ipod || $berry == true)
{  header('location: '.$siteurl.'mobile/user/'.$userp.'/confession'); }

?>

<div class="covering">


<?php include 'menu.php'; ?>

<div class="cov-a">

<?php if($solreklam != ""){ include 'ads/left.php'; } ?>

<div class="content">

<?php include 'profile-info.php'; ?>	
   

<?php if($upanel == "confession"){ include 'confession.php'; } ?>

<?php if($userp == $_SESSION["kullanici"] and $upanel == "block"){ ?>

 <iframe name="block" src="<?php echo $siteurl ?>/block.php" width="750" height="500" frameborder="0" scrolling="no" style="margin-top: 10px; border-radius: 5px;"></iframe>
 
<?php } ?>

<?php if($userp == $_SESSION["kullanici"] and $upanel == "notifications"){ ?>

 <iframe name="notifications" src="<?php echo $siteurl ?>/notifications.php" width="750" height="500" frameborder="0" scrolling="no" style="margin-top: 10px; border-radius: 5px;"></iframe>
 
<?php } ?>

<?php if($userp == $_SESSION["kullanici"] and $upanel == "settings"){ include 'settings.php'; } ?>


<?php include 'pagination.php'; ?>

<?php include 'footer.php'; ?>

</div>

<?php if($sagreklam != ""){ include 'ads/right.php'; } ?>

</div>

</div>

</body>
</html>

<?php ob_end_flush();  ?>