<div class="ads-phone">

<?php echo $telefonreklam ?>

</div>