<div class="ads ads-right">

<div class="ads2">

<?php echo $sagreklam ?>

</div>

</div>