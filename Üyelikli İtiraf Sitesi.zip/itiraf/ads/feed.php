<div class="ads-feed">

<?php echo $ortareklam ?>

<?php 

	$guncellegosterim = $db->prepare("update reklam set goruntulenme=? where id=?");
	$guncellegosterim->execute(array($ortareklam2["goruntulenme"]+1, $ortareklam2["id"]));
	
?>

</div>