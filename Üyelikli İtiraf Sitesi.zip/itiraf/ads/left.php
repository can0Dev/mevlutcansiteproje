<div class="ads ads-left">

<div class="ads2">

<?php echo $solreklam ?>

</div>

</div>