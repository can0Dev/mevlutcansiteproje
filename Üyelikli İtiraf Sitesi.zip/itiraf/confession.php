<?php 

	$itirafsehirbul2 = $db->prepare("SELECT * FROM sehirler where seo=?");
	$itirafsehirbul2->execute(array($sehir));
	$sehirbul2 = $itirafsehirbul2->fetch(PDO::FETCH_ASSOC);
	
include 'confession-list.php';

@$itirafsay = $itiraflaricek ->rowCount();
$itiraflar = $itiraflaricek ->fetchAll(PDO::FETCH_ASSOC);
foreach ($itiraflar as $itiraf){ 


$itirafuyelercek = $db->prepare("SELECT * FROM uyeler where kullanici=?");
$itirafuyelercek ->execute(array($itiraf["yazan"]));
$uyeler = $itirafuyelercek ->fetchAll(PDO::FETCH_ASSOC);
foreach ($uyeler as $uye){ 

include 'emoji-list.php';

$itirafbegenilercek = $db->prepare("SELECT * FROM begeniler where begenen=? and begenilen_id=?");
$itirafbegenilercek ->execute(array($_SESSION["kullanici"], $itiraf["id"]));
$itirafbegeni = $itirafbegenilercek ->fetch(PDO::FETCH_ASSOC);

		$itirafsehirbul = $db->prepare("SELECT * FROM sehirler where sehir=?");
		$itirafsehirbul->execute(array($itiraf["sehir"]));
		$sehirbul = $itirafsehirbul->fetch(PDO::FETCH_ASSOC);
		
	$blockvarmicek = $db->prepare("SELECT * FROM engel where engelleyen=? and engellenen=?");
	$blockvarmicek ->execute(array($_SESSION["kullanici"], $itiraf["yazan"]));
	$blockvarmi = $blockvarmicek ->rowCount();

	if($itiraf["arkaplan"] == "1.jpg"){ $backcolor = "color:#fff; text-shadow: 0px 0px 15px #000;"; }
elseif($itiraf["arkaplan"] == "2.jpg"){ $backcolor = "color:#000; text-shadow: 0px 0px 15px #fff;"; }
elseif($itiraf["arkaplan"] == "3.jpg"){ $backcolor = "color:#000; text-shadow: 0px 1px 15px #fff;"; }
elseif($itiraf["arkaplan"] == "4.jpg"){ $backcolor = "color:#000; text-shadow: 0px 0px 15px #fff;"; }
elseif($itiraf["arkaplan"] == "5.jpg"){ $backcolor = "color:#fff; text-shadow: 0px 0px 15px #000;"; }
elseif($itiraf["arkaplan"] == "6.jpg"){ $backcolor = "color:#000; text-shadow: 0px 0px 15px #fff;"; }
elseif($itiraf["arkaplan"] == "7.jpg"){ $backcolor = "color:#000; text-shadow: 0px 0px 15px #fff;"; }
elseif($itiraf["arkaplan"] == "8.jpg"){ $backcolor = "color:#fff; text-shadow: 0px 0px 15px #000;"; }
elseif($itiraf["arkaplan"] == "9.jpg"){ $backcolor = "color:#fff; text-shadow: 0px 0px 15px #000;"; }
elseif($itiraf["arkaplan"] == "10.jpg"){ $backcolor = "color:#fff; text-shadow: 0px 0px 15px #000;"; }

	$yazisayi = strlen($itiraf["itiraf"]);

	
	if ($yazisayi <= 80){ $fontbuyukluk = "font-size:38px;"; }
elseif ($yazisayi <= 200){ $fontbuyukluk = "font-size:25px;"; } 
elseif ($yazisayi <= 350){ $fontbuyukluk = "font-size:22px;"; } 
elseif ($yazisayi <= 600){ $fontbuyukluk = "font-size:22px; display:block;"; }
elseif ($yazisayi <= 750){ $fontbuyukluk = "font-size:18px; display:block;"; }
else{ $fontbuyukluk = "font-size:18px; display:block;"; }
 ?>

<div class="confession-a shadow" <?php if($blockvarmi >= "1"){ ?>style="display:none;"<?php } ?> >

<?php if($itiraf["reklam"] == "1"){ ?>

<div class="conf-user-info">
<div class="conf-user" style="cursor: context-menu; font-size:12px; padding-top: 7px; height: 17px; color:#099;">Sponsor</div>
</div>

<?php } ?>

<div class="conf-user-info" <?php if($itiraf["reklam"] == "1"){ ?>style="display:none;"<?php } ?> >

<div class="conf-user-img"><a href="user/<?php echo $itiraf["yazan"] ?>"><img src="<?php echo $uye["fotograf"] ?>" width="29" height="29" /></a></div>

<div class="conf-user"><a href="user/<?php echo $itiraf["yazan"] ?>/confession"><?php echo $itiraf["yazan"] ?></a></div>

<?php if($uye["onay"] == "1"){ ?>
<div class="conf-user" style="float:left; margin-left:0;"><img src="img/icon/approved.png" width="21" height="21" />

<div class="tit-hov" style="left: -30px; bottom: -45px;">
<div class="e-hov-u"></div>
Onaylanmış Hesap
</div>

</div>
<?php } ?>

<?php if($itiraf["sehir"] != ""){ ?>
<div class="conf-user" style="margin-left:0; cursor: context-menu; font-size:12px; padding-top: 7px; height: 17px;"><a href="city/<?php echo $sehirbul["seo"] ?>"><?php echo $itiraf["sehir"] ?></a>

<div class="tit-hov" style=" left: -50%; bottom: -60px; width: 50px; right: -50%; margin: auto;">
<div class="e-hov-u"></div>
İtirafın Yaşandığı Şehir
</div>

</div>
<?php } ?>

<?php if($itiraf["universite"] != ""){ 


	$universitebul5 = $db->prepare("SELECT * FROM universite where universite=?");
	$universitebul5->execute(array($itiraf["universite"]));
	$universite5 = $universitebul5->fetch(PDO::FETCH_ASSOC);

if(strlen($itiraf["universite"]) <= "36"){ $kisauni = $itiraf["universite"]; }else{ $kisauni = substr($itiraf["universite"], 0, 35)."..."; }

?>

<div class="conf-user" style="margin-left:0; cursor: context-menu; font-size:12px; padding-top: 7px; height: 17px;"><a href="university/<?php echo $universite5["seo"] ?>" title="<?php echo $itiraf["universite"] ?>"><?php echo $kisauni ?></a>

<div class="tit-hov" style=" left: -50%; bottom: -60px; width: 50px; right: -50%; margin: auto;">
<div class="e-hov-u"></div>
İtirafın Yaşandığı Üniversite
</div>

</div>
<?php } ?>

<div class="conf-user" style="margin-left:0; cursor: context-menu; font-size:12px; padding-top: 7px; height: 17px;"><a href="co/<?php echo $itiraf["id"] ?>"><?php echo $itiraf["tarih"] ?></a>

<div class="tit-hov" style="left: -8px; bottom: -45px;">
<div class="e-hov-u"></div>
Paylaşılma Tarihi
</div>

</div>
<?php if($_SESSION["kullanici"] == $ceo){ ?>
<div class="conf-user" style="margin-left:0; cursor: context-menu; font-size:12px; padding-top: 7px; height: 17px;"><?php echo $itiraf["id"] ?>

<div class="tit-hov" style="left: -20px; bottom: -29px;">
<div class="e-hov-u"></div>
İtiraf İD
</div>

</div>
<?php } ?>

<?php if($itiraf["yazan"] == $_SESSION["kullanici"]){ ?>
<div class="conf-user" style="float:right; margin-left:0;"><a href="delete.php?conf=<?php echo $itiraf["id"] ?>" onclick="return deleteconf();"><img src="img/icon/delete.png" width="21" height="21" /></a>

<div class="tit-hov" style="left: -18px; bottom: -45px;">
<div class="e-hov-u"></div>
İtirafı Sil
</div>


</div>
<?php } ?>

<?php if($_SESSION and $itiraf["yazan"] != $_SESSION["kullanici"]){ ?>
<div class="conf-user" style="float:right;"><a href="insert.php?block=<?php echo $itiraf["yazan"] ?>" onclick="return blockuser();"><img src="img/icon/block.png" width="21" height="21" /></a>

<div class="tit-hov" style="left: -30px; bottom: -78px;">
<div class="e-hov-u"></div>
Bu Kullanıcının İtiraflarını Gizle
</div>


</div>

<?php } ?>

</div>

<div class="confession" style="display:table; <?php if($itiraf["reklam"] != "1"){ ?> background:url(img/background/<?php echo $itiraf["arkaplan"] ?>); background-size:cover; <?php echo $backcolor; ?> <?php }else{ ?> height:auto; <?php } ?> ">


<div class="confession-t" style=" <?php if($itiraf["reklam"] == "1"){ ?> height:auto; <?php } ?> <?php echo $fontbuyukluk; ?>">

<?php if($itiraf["reklam"] != "1"){ ?>

<?php echo $itiraf["itiraf"]; ?>

<?php }else{

	include 'ads/feed.php';
	
	} ?>

</div>



</div>

<?php if($itiraf["reklam"] != "1"){ ?>
<iframe name="like" src="<?php echo $siteurl ?>confession-like.php?id=<?php echo $itiraf["id"] ?>" class="likeframe" width="750" height="118" frameborder="0" scrolling="no" style="border-bottom-left-radius:5px; border-bottom-right-radius:5px;"></iframe>
<?php } ?>


</div>

<?php } } ?>



<div class="no-conf shadow">

<?php 

if($sehir){ 


if($itirafsay <= "0"){ 

?>
	
<div class="no-conf-t"><font color="#099"><?php echo $sehirbul2["sehir"] ?></font> Şehrinde paylaşılmış itiraf yok! <br /> <br /> <font style="font-size:18px;"><a href="<?php if($_SESSION){ echo $siteurl; }else{ echo $siteurl."signup"; } ?>" style="outline:none; text-decoration:none; color:#000;">Bu şehir'deki ilk itirafı sen yaz!</a>
</font></div>

<?php } } ?>


<?php 

if($act == "flow-now"){

if($itirafsay <= "0"){ 

?>
	
<div class="no-conf-t">Şimdi paylaşılan itiraf yok! <br /> <br /> <font style="font-size:18px;"><a href="<?php if($_SESSION){ echo $siteurl; }else{ echo $siteurl."signup"; } ?>" style="outline:none; text-decoration:none; color:#000;">Hemen ilk itirafı sen yaz!</a>
</font></div>

<?php } } ?>


<?php 

if($act == "flow-1-hour-ago"){

if($itirafsay <= "0"){ 

?>
	
<div class="no-conf-t">Yakınlarda paylaşılmış itiraf yok! <br /> <br /> <font style="font-size:18px;"><a href="<?php if($_SESSION){ echo $siteurl; }else{ echo $siteurl."signup"; } ?>" style="outline:none; text-decoration:none; color:#000;">Hemen itirafını paylaş!</a>
</font></div>

<?php } } ?>


<?php 

if($act == "flow-1-day-ago"){

if($itirafsay <= "0"){ 

?>
	
<div class="no-conf-t">Düne bakıyorum da bomboş! <br /> <br /> <font style="font-size:18px;"><a href="<?php if($_SESSION){ echo $siteurl; }else{ echo $siteurl."signup"; } ?>" style="outline:none; text-decoration:none; color:#000;">Hemen itiraf paylaş!</a>
</font></div>

<?php } } ?>

<?php 

if($act == "flow-1-week-ago"){

if($itirafsay <= "0"){ 

?>
	
<div class="no-conf-t">1 hafta öncesinde hayat bomboş! <br /> <br /> <font style="font-size:18px;"><a href="<?php if($_SESSION){ echo $siteurl; }else{ echo $siteurl."signup"; } ?>" style="outline:none; text-decoration:none; color:#000;">Hemen itiraf paylaş!</a>
</font></div>

<?php } } ?>

<?php 

if($upanel){

if($itirafsay <= "0"){ 

?>
	
<div class="no-conf-t" style="font-size:40px;">Daha hiç itiraf paylaşılmamış!</div>

<?php } } ?>

<?php 

if($_GET["university"]){

if($itirafsay <= "0"){ 

?>
	
<div class="no-conf-t">

<br />
Hiç itiraf yok! 

<br /> <br /> 

<font style="font-size:18px;"><a href="<?php if($_SESSION){ echo $siteurl; }else{ echo $siteurl."signup"; } ?>" style="outline:none; text-decoration:none; color:#000;">Hemen ilk itirafı sen yaz!</a>
</font></div>

<?php } } ?>

<?php 

if($detay){

if($itirafsay <= "0"){ 

?>
	
<div class="no-conf-t" style="font-size:40px; margin-bottom:10px;">İtiraf paylaşılmamış veya silinmiş olabilir!</div>

<?php } } ?>

</div>

