<?php
ob_start();

include 'conn.php';
include 'head.php';

$sayfa = $_GET["pg"];

?>

<style>

.page-t{width:740px; margin:5px;}
.page-tit{width:740px; font-family: 'Courgette', cursive; font-size:24px; text-align:center; margin:10px 0;}

</style>

<div class="covering">

<?php include 'menu.php'; ?>

<div class="cov-a">

<?php if($solreklam != ""){ include 'ads/left.php'; } ?>

<div class="content">

<div class="profile-info shadow" style="min-height:500px; display:table;">

<div class="page-t">

<?php if($sayfa == "user-agreement"){ ?>

<head><title>Kullanıcı Sözleşmesi - <?php echo $sitename ?></title></head>

<div class="page-tit">Kullanıcı Sözleşmesi</div>

<?php echo $kullaniciyazi ?>

<?php } ?>



<?php if($sayfa == "privacy-and-cookies"){ ?>

<head><title>Gizlilik ve Çerezler - <?php echo $sitename ?></title></head>

<div class="page-tit">Gizlilik ve Çerezler</div>

<?php echo $gizlilikyazi ?>

<?php } ?>



<?php if($sayfa == "site-legal-rights"){ ?>

<head><title>Site Yasal Hakları - <?php echo $sitename ?></title></head>

<div class="page-tit">Site Yasal Hakları</div>

<?php echo $siteyasalyazi ?>

<?php } ?>



<?php if($sayfa == "advertisement"){ ?>

<head><title>Reklam - <?php echo $sitename ?></title></head>

<div class="page-tit">Reklam</div>

<?php echo $reklamyazi ?>

<?php } ?>



</div>

</div>


<?php include 'footer.php'; ?>

</div>

<?php if($sagreklam != ""){ include 'ads/right.php'; } ?>

</div>

</div>

<?php

 ob_end_flush();
 
?>