<?php

$itirafbegeni = $db->prepare("SELECT * FROM begeniler where begenilen_id=? and emoji=?");
$itirafbegeni ->execute(array($itiraf["id"], "1"));
$kalpbegeni = $itirafbegeni->rowCount();

$itirafbegeni2 = $db->prepare("SELECT * FROM begeniler where begenilen_id=? and emoji=?");
$itirafbegeni2 ->execute(array($itiraf["id"], "2"));
$gulenbegeni = $itirafbegeni2->rowCount();

$itirafbegeni3 = $db->prepare("SELECT * FROM begeniler where begenilen_id=? and emoji=?");
$itirafbegeni3 ->execute(array($itiraf["id"], "3"));
$sinirlibegeni = $itirafbegeni3->rowCount();

$itirafbegeni4 = $db->prepare("SELECT * FROM begeniler where begenilen_id=? and emoji=?");
$itirafbegeni4 ->execute(array($itiraf["id"], "4"));
$uzgunbegeni = $itirafbegeni4->rowCount();

$itirafbegeni5 = $db->prepare("SELECT * FROM begeniler where begenilen_id=? and emoji=?");
$itirafbegeni5 ->execute(array($itiraf["id"], "5"));
$saskinbegeni = $itirafbegeni5->rowCount();

$itirafyorum1 = $db->prepare("SELECT * FROM yorumlar where yapilan_id=?");
$itirafyorum1 ->execute(array($itiraf["id"]));
$itirafyorum = $itirafyorum1->rowCount();

?>