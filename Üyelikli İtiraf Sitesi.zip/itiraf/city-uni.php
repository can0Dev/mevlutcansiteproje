<div class="city-uni shadow">

<div class="city-uni-box">

<div style="margin:auto; display:table;">

<form action="go.php" method="get" style="margin:0;">

<select class="conf-select" style="width:225px; padding:10px; margin-left:0;" name="city2">

	<option selected disabled hidden>Şehir İtirafları</option>
	<?php include 'city.php'; ?>
    </select>

<input type="submit" class="conf-submit" style="width:100px; margin-left: -10px; padding: 8px; margin:auto; background: #fff; color:#000; border: 1px #ccc solid;" value="Listele" />

</form>

</div>

</div>

<div class="city-uni-box">

<div style="margin:auto; display:table;">

<form action="go.php" method="get" style="margin:0;">

<select class="conf-select" style="width:225px; padding:10px; margin-left:0;" name="university">

	<option selected disabled hidden>Üniversite İtirafları</option>
	<?php include 'university.php'; ?>
    </select>

<input type="submit" class="conf-submit" style="width:100px; margin-left: -10px; padding: 8px; margin:auto; background: #fff; color:#000; border: 1px #ccc solid;" value="Listele" />

</form>

</div>

</div>

</div>

