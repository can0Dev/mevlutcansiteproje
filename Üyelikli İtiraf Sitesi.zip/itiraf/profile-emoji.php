<?php

$itirafbegenip = $db->prepare("SELECT * FROM begeniler where begenilen=? and emoji=?");
$itirafbegenip ->execute(array($userp, "1"));
$kalpbegenip = $itirafbegenip->rowCount();

$itirafbegenip2 = $db->prepare("SELECT * FROM begeniler where begenilen=? and emoji=?");
$itirafbegenip2 ->execute(array($userp, "2"));
$gulenbegenip = $itirafbegenip2->rowCount();

$itirafbegenip4 = $db->prepare("SELECT * FROM begeniler where begenilen=? and emoji=?");
$itirafbegenip4 ->execute(array($userp, "3"));
$sinirlibegenip = $itirafbegenip4->rowCount();

$itirafbegenip5 = $db->prepare("SELECT * FROM begeniler where begenilen=? and emoji=?");
$itirafbegenip5 ->execute(array($userp, "4"));
$uzgunbegenip = $itirafbegenip5->rowCount();

$itirafbegenip6 = $db->prepare("SELECT * FROM begeniler where begenilen=? and emoji=?");
$itirafbegenip6 ->execute(array($userp, "5"));
$saskinbegenip = $itirafbegenip6->rowCount();

$itirafyorum6 = $db->prepare("SELECT * FROM yorumlar where yapilan=?");
$itirafyorum6 ->execute(array($userp));
$itirafyorum1 = $itirafyorum6->rowCount();


?>