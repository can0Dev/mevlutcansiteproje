<?php 
ob_start();
include ("conn.php");
session_start();

setcookie("onlitm",$cookievalue,time()-60*60*24*365);

session_destroy();


header("location: ".$siteurl."");


 ob_end_flush();  ?>
