<?php

	$benimbilgiler = $db->prepare("SELECT * FROM uyeler where kullanici=?");
	$benimbilgiler->execute(array($_SESSION["kullanici"]));
	$benim = $benimbilgiler->fetch(PDO::FETCH_ASSOC);
	
	?>
    
<div class="menu-a">

<div class="menu">

<div class="go-u-search">


<form action="search" method="get" style="margin:0; margin-top:5px;">
				
				<input type="text" name="user" class="search-input" autocomplete="off" placeholder="Kullanıcı Adı" value="<?php echo $Gelen ?>" />
				
				<input type="submit" class="search-submit" value="ARA" />
				
				
			</form>
           
            
</div>

<a href="<?php echo $siteurl ?>"><div class="banner">

<div class="tit-hov" style="left: -15px; bottom: -35px; z-index: 3;">
<div class="e-hov-u"></div>
<?php echo $sitename ?>
</div>

</div></a>

<?php if($_SESSION){ ?>

<div class="user-panel">

<div class="user">

<a href="user/<?php echo $_SESSION["kullanici"] ?>"><div class="user-img" style="background:url(<?php echo $benim["fotograf"] ?>); background-size:cover;"></div></a>
</div>


<div class="user-name"><a href="user/<?php echo $_SESSION["kullanici"] ?>/confession"><?php echo $_SESSION["kullanici"] ?></a></div>

<?php if($_SESSION["kullanici"] == $ceo){ ?>

<div class="user-link"><a href="<?php echo $siteurl ?>ybbe-panel/">Panel</a></div>

<?php } ?>

<?php 

		$yorumbildirim = $db->prepare("SELECT * FROM yorumlar where yapilan=? and goruldumu=?");
		$yorumbildirim ->execute(array($_SESSION["kullanici"], "0"));
		$bildirim = $yorumbildirim ->rowCount();
		
if($bildirim >= "1"){ ?>

<div class="user-link" id="comment-noti" style="position:relative;"><a href="user/<?php echo $_SESSION["kullanici"] ?>/notifications"><div style="width:20px; height:20px; margin-top:1px; border-radius:50%; background:coral;"></div></a>

<div class="tit-hov" style="left: -12px; bottom: -53px; z-index: 3;">
<div class="e-hov-u"></div>
Yeni yorum var!
</div>


</div>

<?php } ?>

<div class="user-link"><a href="logout.php">Çıkış</a></div>

</div>

<?php }else{ ?> 

<div class="user-panel">

<div class="user-link" style="height:auto; padding:5px; margin-top:7px;"><a href="signup">Kayıt ol, itiraflarını paylaş</a></div>

</div>

<?php } ?>

</div>

</div>