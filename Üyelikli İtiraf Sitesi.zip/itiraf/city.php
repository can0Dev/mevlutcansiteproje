<?php 
	
		$sehirlericek = $db->prepare("SELECT * FROM sehirler");
		$sehirlericek->execute(array());
		$sehirleri = $sehirlericek->fetchAll(PDO::FETCH_ASSOC);
		foreach ($sehirleri as $sehirler){ 
	
?>
    
    <option value="<?php echo $sehirler["seo"] ?>"><?php echo $sehirler["sehir"] ?></option>

<?php } ?>