<?php

	$sehir 		= $_GET["city"];
	$uni = $_GET["university"];
	
	if($sehir){ ?>
	
<div class="flow-a shadow">

<div style="display:table; margin:auto; font-size: 25px; font-family: 'Courgette', cursive; padding-top: 5px;">

<?php

		$itirafsehirbul3 = $db->prepare("SELECT * FROM sehirler where seo=?");
		$itirafsehirbul3->execute(array($sehir));
		$sehirbul3 = $itirafsehirbul3->fetch(PDO::FETCH_ASSOC);

 echo 'Listelenen Şehir <font style="color:#099">'.$sehirbul3["sehir"].'</font>';  ?>

</div>

</div>

<?php } 

elseif($uni){ ?>
	
<div class="flow-a shadow">

<div style="display:table; margin:auto; font-size: 25px; font-family: 'Courgette', cursive; padding-top: 5px;">

<?php

		$universitebul3 = $db->prepare("SELECT * FROM universite where seo=?");
		$universitebul3->execute(array($uni));
		$universite4 = $universitebul3->fetch(PDO::FETCH_ASSOC);
?>

  Listelenen Üniversite <font style="color:#099;<?php if(strlen($universite4["universite"]) >= "36"){ ?>font-size:18px;<?php } ?>"><?php echo $universite4["universite"]?></font>

</div>

</div>

<?php }else{
?>
<div class="flow-a shadow">
<div style="display:table; margin:auto;">

<div class="flow" style="padding-left:0;">
<a href="flow-now" <?php if($act
 == "flow-now"){ echo 'style="font-weight:bold; color:darkorange;"'; } ?>>Şimdi</a> <?php if($act == "flow-now"){ ?><a href="<?php echo $siteurl ?>" title="Akışı kapat">x</a><?php } ?>
 </div>

<div class="flow">
<a href="flow-1-hour-ago" <?php if($act == "flow-1-hour-ago"){ echo 'style="font-weight:bold; color:darkorange;"'; } ?>>1 saat ve öncesi</a> <?php if($act == "flow-1-hour-ago"){ ?><a href="<?php echo $siteurl ?>" title="Akışı kapat">x</a><?php } ?>
</div>

<div class="flow">
<a href="flow-1-day-ago" <?php if($act == "flow-1-day-ago"){ echo 'style="font-weight:bold; color:darkorange;"'; } ?>>1 gün ve öncesi</a> <?php if($act == "flow-1-day-ago"){ ?><a href="<?php echo $siteurl ?>" title="Akışı kapat">x</a><?php } ?>
</div>

<div class="flow" style="border:none; padding-right:0;"><a href="flow-1-week-ago" <?php if($act == "flow-1-week-ago"){ echo 'style="font-weight:bold; color:darkorange;"'; } ?>>1 hafta ve öncesi</a> <?php if($act == "flow-1-week-ago"){ ?><a href="<?php echo $siteurl ?>" title="Akışı kapat">x</a><?php } ?></div>
</div>

</div>

<?php } ?>