<?php 

ob_start();
session_start();

	include 'conn.php';
	
	
	$begen = $_GET["like"];
	$emoji = $_GET["e"];
	$ben   = $_SESSION["kullanici"];
	$block = $_GET["block"];
	
if($begen){

if($_SESSION){

	
		$itirafpaylasanbul = $db->prepare("SELECT * FROM itiraf where id=?");
		$itirafpaylasanbul->execute(array($begen));
		$itirafyaplasan = $itirafpaylasanbul->fetch(PDO::FETCH_ASSOC);
		
	$user  = $itirafyaplasan["yazan"];
	
		$begenibulcek = $db->prepare("SELECT * FROM uyeler where kullanici=?");
		$begenibulcek->execute(array($user));
		$begenibul = $begenibulcek->fetch(PDO::FETCH_ASSOC);

	$eklebegeni = $begenibul["begeni"]+1;
		
	
	$itirafuyelercek = $db->prepare("SELECT * FROM begeniler where begenen=? and begenilen_id=?");
	$itirafuyelercek ->execute(array($ben, $begen));
	$begenivarmi = $itirafuyelercek ->rowCount();
	
	
	if($begenivarmi <= "0"){
	
	$kaydetbegeni = $db->prepare("insert into begeniler set begenen=?, begenilen=?, begenilen_id=?, emoji=?");
	$kaydetbegeni->execute(array($ben, $user, $begen, $emoji));	
	
	if($kaydetbegeni){
		
	$guncellebegeni = $db->prepare("update uyeler set begeni=? where kullanici=?");
	$guncellebegeni->execute(array($eklebegeni, $user));
		
		
		header("location: ".$_SERVER['HTTP_REFERER']."");
			
	}
	
		
	}
		
	
	}else{
		
		header("location: ".$siteurl."confession-like.php?id=".$begen."&nouser=1");
		
		}
	
	}
	

if($block){

if($_SESSION){
	
	
if($_SESSION["kullanici"] == $block){
	
		header("location: ".$_SERVER['HTTP_REFERER']."");
	
	}else{

	
	$blockvarmicek = $db->prepare("SELECT * FROM engel where engelleyen=? and engellenen=?");
	$blockvarmicek ->execute(array($ben, $block));
	$blockvarmi = $blockvarmicek ->rowCount();
	
	
	if($blockvarmi <= "0"){
	
	$kaydetblock = $db->prepare("insert into engel set engelleyen=?, engellenen=?");
	$kaydetblock->execute(array($ben, $block));	
	
	if($kaydetblock){

		header("location: ".$_SERVER['HTTP_REFERER']."");
			
	}else{
		
		header("location: ".$_SERVER['HTTP_REFERER']."");
		
		}
	
		
	}
	
	}
	
}else{
	
	header("location: ".$_SERVER['HTTP_REFERER']."");
		
	}

}






//header("location: ".$_SERVER['HTTP_REFERER']."");


ob_end_flush();

?>