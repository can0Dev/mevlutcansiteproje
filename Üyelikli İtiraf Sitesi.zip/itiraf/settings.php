<?php 

	$uyeayarlar = $db->prepare("SELECT * FROM uyeler where kullanici=?");
	$uyeayarlar->execute(array($_SESSION["kullanici"]));
	$uyeayar = $uyeayarlar->fetch(PDO::FETCH_ASSOC);
	
?>


<style>

.shadow:hover{box-shadow: 0 0 5px #099; -moz-box-shadow: 0 0 5px #099; -webkit-box-shadow: 0 0 5px #099;}

</style>

<div class="settings shadow">

<div class="settings-tit">Fotoğraf</div>

<div class="p-i-box" style="background:#f1f1f1; border-radius:5px; margin-top:0;">
<div class="center"><img src="<?php echo $uyeayar["fotograf"] ?>" width="150" height="170" /></div>
<?php if($uyeayar["fotograf"] != "img/no-photo.png"){ ?> 
<div class="center" style="background:#099; padding:5px; border-radius:5px;"><a href="delete.php?photo=<?php echo $uyeayar["fotograf"] ?>" style="outline:none; text-decoration:none; color:#fff;">Fotoğrafı Kaldır</a></div>
<?php } ?>
</div>


<div class="p-i-box" style="background:#f1f1f1; border-radius:5px; margin-top:0; display:table;">

<form action="" method="post" name="form1" enctype="multipart/form-data" style="display: table-cell; vertical-align: middle; text-align: center;">
 
<input type="file" name="photo" class="conf-submit" style="width:270px; background:#099; border:1px #099 solid; color:#fff; font-size:12px;" /><br/>
 
<input type="submit" name="gophoto" value="Güncelle" class="conf-submit" style="width:270px; background:#099; border:1px #099 solid; color:#fff;"  />
 
</form>

</div>
<?php 

if($_POST["gophoto"]){
 
 if($uyeayar["fotograf"] != "img/no-photo.png"){
	 


    if ($_FILES["photo"]["size"]<1024*1024){
	
        if ($_FILES["photo"]["type"]=="image/jpeg"){ 
 
            $dosya_adi   =    $_FILES["photo"]["name"];
 
            $uret=array("as","rt","ty","yu","fg","bb","by");
            $uzanti=substr($dosya_adi,-4,4);
            $sayi_tut=rand(1,10000);
			$sayi_tut2=rand(1,10000);
 
            $yeni_ad="img/user/".$uret[rand(0,6)].$sayi_tut.$sayi_tut2.$uzanti;
 
 
            if (move_uploaded_file($_FILES["photo"]["tmp_name"],$yeni_ad)){
                echo '<div class="center" style="color:#090;">Fotoğraf başarıyla yüklendi</div>';
				
		$fotobenimmicek = $db->prepare("SELECT * FROM uyeler where fotograf=? and kullanici=?");
		$fotobenimmicek->execute(array($uyeayar["fotograf"], $uyeayar["kullanici"]));
		$fotobenimmi = $fotobenimmicek->rowCount();
	
	if($fotobenimmi >= "1"){
	
	unlink($uyeayar["fotograf"]);
	
	}
 
 
	$guncelleresim = $db->prepare("update uyeler set fotograf=? where kullanici=?");
	$guncelleresim->execute(array($yeni_ad, $uyeayar["kullanici"]));
 
 header("location: ".$_SERVER['HTTP_REFERER']."");
 
        }else{
            echo '<div class="center" style="color:red;">Fotoğraf Yüklenemedi!</div>';
        }
    }else{
        echo '<div class="center" style="color:red;">Fotoğraf jpeg formatında olmalıdır!</div>';
    }
    }else{          
        echo '<div class="center" style="color:red;">Dosya boyutu en fazla 1 Mb olmalıdır!</div>';
    }
}else{
	
	if ($_FILES["photo"]["size"]<1024*1024){
	
        if ($_FILES["photo"]["type"]=="image/jpeg"){ 
 
            $dosya_adi   =    $_FILES["photo"]["name"];
 
            $uret=array("as","rt","ty","yu","fg","bb","by");
            $uzanti=substr($dosya_adi,-4,4);
            $sayi_tut=rand(1,10000);
			$sayi_tut2=rand(1,10000);
 
            $yeni_ad="img/user/".$uret[rand(0,6)].$sayi_tut.$sayi_tut2.$uzanti;
 
 
            if (move_uploaded_file($_FILES["photo"]["tmp_name"],$yeni_ad)){
                echo '<div class="center" style="color:#090;">Fotoğraf başarıyla yüklendi</div>';
			
 
	$guncelleresim = $db->prepare("update uyeler set fotograf=? where kullanici=?");
	$guncelleresim->execute(array($yeni_ad, $uyeayar["kullanici"]));
 
 header("location: ".$_SERVER['HTTP_REFERER']."");
 
        }else{
            echo '<div class="center" style="color:red;">Fotoğraf Yüklenemedi!</div>';
        }
    }else{
        echo '<div class="center" style="color:red;">Fotoğraf jpeg formatında olmalıdır!</div>';
    }
    }else{          
        echo '<div class="center" style="color:red;">Dosya boyutu en fazla 1 Mb olmalıdır!</div>';
    }
}

}

?>



</div>

<div class="settings shadow">

<div class="settings-tit">Kişisel - Sosyal</div>

<form action="" method="post">

<div class="center" style="padding:0;">

<select class="conf-select" name="city" style="width:270px; padding:10px; border:1px #099 solid; margin-bottom:13px;">

	<option selected disabled hidden><?php if($uyeayar["sehir"] != ""){ echo $uyeayar["sehir"]; }else{ ?>Şehir<?php } ?></option>
	<?php 
	
		$sehirlericek = $db->prepare("SELECT * FROM sehirler");
		$sehirlericek->execute(array());
		$sehirleri = $sehirlericek->fetchAll(PDO::FETCH_ASSOC);
		foreach ($sehirleri as $sehirler){ 
	
?>
    
    <option value="<?php echo $sehirler["sehir"] ?>"><?php echo $sehirler["sehir"] ?></option>

<?php } ?>
	</select>
    
    <select class="conf-select" name="gender" style="width:270px; padding:10px; border:1px #099 solid; margin-bottom:13px;">

	<option selected disabled hidden><?php if($uyeayar["cinsiyet"] != ""){ echo $uyeayar["cinsiyet"]; }else{ ?>Cinsiyet<?php } ?></option>
    <option value="Erkek">Erkek</option>
    <option value="Kadın">Kadın</option>
    
</select>

</div>

<div class="center" style="padding:0;">

<input type="text" name="facebook" placeholder="Facebook Kullanıcı Adın" class="conf-input" value="<?php echo $uyeayar["facebook"] ?>" title="Facebook" style="border:1px #099 solid;" maxlength="30" />
<input type="text" name="twitter" placeholder="Twitter Kullanıcı Adın" class="conf-input" value="<?php echo $uyeayar["twitter"] ?>" title="Twitter" style="border:1px #099 solid;" maxlength="30" />

</div>

<div class="center" style="padding:0;">

<input type="text" name="instagram" placeholder="İnstagram Kullanıcı Adın" class="conf-input" value="<?php echo $uyeayar["instagram"] ?>" title="İnstagram" style="border:1px #099 solid;" maxlength="30" />
<input type="text" name="youtube" placeholder="Youtube Kullanıcı Adın" class="conf-input" value="<?php echo $uyeayar["youtube"] ?>" title="Youtube" style="border:1px #099 solid;" maxlength="75" />

</div>

<div class="center" style="padding:0;">

<input type="submit" value="Güncelle" class="conf-submit" name="personal" style="width:270px; background:#099; border:1px #099 solid; color:#fff;" />

</div>

</form>

<?php

$sehir3		= $_POST["city"];
$cinsiyet3	= $_POST["gender"];
$facebook 	= $_POST["facebook"];
$twitter 	= $_POST["twitter"];
$instagram  = $_POST["instagram"];
$youtube	= $_POST["youtube"];

if($sehir3 != ""){ $sehir4 = $sehir3; }else{ $sehir4 = $uyeayar["sehir"]; }
if($cinsiyet3 != ""){ $cinsiyet = $cinsiyet3; }else{ $cinsiyet = $uyeayar["cinsiyet"]; }

if($_POST["personal"]){

	$guncellekisisel = $db->prepare("update uyeler set sehir=?, cinsiyet=?, facebook=?, twitter=?, instagram=?, youtube=? where kullanici=?");
	$guncellekisisel->execute(array($sehir4, $cinsiyet, $facebook, $twitter, $instagram, $youtube, $uyeayar["kullanici"]));
			
			if ($guncellekisisel){ 
			
		
		echo '<div class="center" style="color:green;">Ayarlar güncellendi!</div>';
			
	}
	
}

?>

</div>


<div class="settings shadow">

<div class="settings-tit" <?php if($uyeayar["eposta"] == ""){ ?>style="color:coral;"<?php } ?>>E-Posta</div>

<div class="settings-tit" style="font-size:19px; padding:0;">Şifreni unuttuğun zaman yardımına koşacak güncel e-posta adresini ekle</div>
<div class="settings-tit" style="font-size:16px; padding:10px 0;">Gereksiz mail göndermiyoruz! Sadece şifre sıfırlama</div>

<form action="" method="post">

<div class="center" style="padding:0;">

<input type="text" name="mail" placeholder="E-Posta" value="<?php echo $uyeayar["eposta"] ?>" class="conf-input" style="border:1px #099 solid;" maxlength="50" />

</div>

<div class="center" style="padding:0;">

<input type="submit" value="Güncelle" class="conf-submit" name="gomail" style="width:270px; background:#099; border:1px #099 solid; color:#fff;" />

</div>

</form>

<?php 

$eposta = trim($_POST["mail"]);

	$epostavarmicek = $db->prepare("SELECT * FROM uyeler where eposta=?");
	$epostavarmicek->execute(array($eposta));
	$epostavarmi = $epostavarmicek->rowCount();

if($_POST["gomail"]){
	
	if($eposta != ""){
		
		if($epostavarmi >= "1"){
			
			echo '<div class="center" style="color:red;">E-Posta başkası tarafından kullanılıyor!</div>';
			
			}else{

	$guncelleeposta = $db->prepare("update uyeler set eposta=? where kullanici=?");
	$guncelleeposta->execute(array($eposta, $uyeayar["kullanici"]));
			
			if ($guncelleeposta){ 
			
		
		echo '<div class="center" style="color:green;">E-Posta güncellendi!</div>';
			
	}
	
	}
	
}else{ echo '<div class="center" style="color:red;">E-Posta alanı boş!</div>'; }

}

?>

</div>


<div class="settings shadow">

<div class="settings-tit">Şifre</div>

<form action="" method="post">

<div class="center" style="padding:0;">

<input type="password" name="oldpass" placeholder="Eski Şifre" class="conf-input" style="border:1px #099 solid;" maxlength="20" />
<input type="password" name="newpass" placeholder="Yeni Şifre" class="conf-input" style="border:1px #099 solid;" maxlength="20" />

</div>

<div class="center" style="padding:0;">

<input type="submit" value="Güncelle" class="conf-submit" name="gopass" style="width:270px; background:#099; border:1px #099 solid; color:#fff;" />

</div>

</form>

<?php

$eskiparola  = md5($_POST["oldpass"]);
$yeniparola  = md5($_POST["newpass"]);
$yeniparola2 = $_POST["newpass"];


if($_POST["gopass"]){
	
	if($eskiparola != "" or $yeniparola != ""){

	if($eskiparola == $uyeayar["sifre"]){
		
		if(strlen($yeniparola2) < 6){ echo '<div class="center" style="color:red;">Şifre en az 6 karakter olmalıdır!</div>'; }else{
	
	$guncelleparola = $db->prepare("update uyeler set sifre=? where kullanici=?");
	$guncelleparola->execute(array($yeniparola, $uyeayar["kullanici"]));
			
			if ($guncelleparola){ 
			
		
		echo '<div class="center" style="color:green;">Şifre güncellendi!</div>';
		
			
	}
	
	}
	
	}else{ echo '<div class="center" style="color:red;">Eski şifre birbiriyle uyuşmuyor!</div>'; }
	
}else{ echo '<div class="center" style="color:red;">Şifre alanı boş!</div>'; }

}



?>

</div>

