<?php

ob_start();
session_start();

	include 'conn.php';
		
   $Gelen = trim($_GET["s"]);


   if($Gelen == ""){header("location: ".$_SERVER['HTTP_REFERER']."");}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<?php include 'head.php'; ?>
<title><?php echo $Gelen." Arama Sonuçları - ".$sitename ?></title>

</head>

<body>

<div class="covering">

<?php include 'menu.php'; ?>

<div class="cov-a">

<?php if($solreklam != ""){ include 'ads/left.php'; } ?>

<div class="content">

<div class="search-box shadow">

<div class="search-snc-t">Aranan kullanıcı <font color="#099"><?php echo $Gelen ?></font></div>

<?php

$page  			 = @intval($_GET['page']); if(!$page) $page = "1";
$ilansay  		 = $db->prepare("select * from uyeler where kullanici LIKE ? order by id desc");
$ilansay         -> execute(array('%'.$Gelen.'%'));
$toplamsayi  	 = $ilansay->rowCount();
$limit			 = "10";
$sayfa_sayisi	 = round($toplamsayi/$limit); if($page > $sayfa_sayisi){$page = 1;}
$goster   		 = $page * $limit - $limit;
$gorunensayfa    = 6;

$Ara   = $db->prepare("SELECT * FROM uyeler WHERE kullanici LIKE ? order by id DESC limit $goster,$limit");
$Ara->execute(array('%'.$Gelen.'%')); 

$Liste   = $Ara->fetchAll(PDO::FETCH_ASSOC);

if($Ara->rowCount() != "0"){ 

   foreach($Liste as $kayit){
	  

	   $arauyelercek = $db->prepare("SELECT * FROM uyeler WHERE id=? order by id DESC");
	   $arauyelercek->execute(array($kayit["id"]));
	   $arauyeler = $arauyelercek->fetchAll(PDO::FETCH_ASSOC);

foreach ($arauyeler as $arauye){ 

		$itiraflarisay = $db->prepare("SELECT * FROM itiraf where yazan=?");
		$itiraflarisay->execute(array($arauye["kullanici"]));
		$itirafsay = $itiraflarisay->rowCount();
		
	  ?> 
      

   <div class="search-ok-a">

   <a href="user/<?php echo $arauye["kullanici"] ?>/confession"><div class="search-ok-img"><img src="<?php echo $arauye["fotograf"] ?>" width="50" height="50" /></div></a>
   
   <div class="search-ok-title"><a href="user/<?php echo $arauye["kullanici"] ?>/confession"><?php echo $arauye["kullanici"] ?></a>
   
   <?php if($arauye["onay"] == "1"){ ?><img src="img/icon/approved.png" width="15" height="15" style="margin-left:5px;" /><?php } ?>
   
   </div>
   
   <div class="search-ok-info">
   
   <div class="search-ok-info-text"><b><?php echo $arauye["cinsiyet"] ?></b></div>
   <?php if($arauye["sehir"] != ""){ ?>
   <div class="search-ok-info-text"> - <?php echo $arauye["sehir"] ?></div>
   <?php } ?>
   <div class="search-ok-info-text"> - <b><?php echo $itirafsay ?></b> İtiraf</div>
   
   </div>
	
    </div>
   
   

<?php } } ?>


<?php 
	if ($toplamsayi <= "10"){}else{ ?>
    
    <div class="pagination shadow" style="margin-top:15px;">
    <div style="display:table; margin:auto;">
    
    <?php 

for($i = $page - $gorunensayfa; $i < $page + $gorunensayfa +1; $i++){

   if($i > 0 and $i <= $sayfa_sayisi){

      if($i == $page){

         echo '<div class="sy-a" style="background:coral; cursor:pointer;"><a>'.$i.'</a></div>';

      }else{
		  
         echo '<a href="search.php?user='.$Gelen.'&page='.$i.'" style="outline:none; text-decoration:none; color:#fff;"><div class="sy-a">'.$i.'</div></a>';


      }

   }

}
?>
    </div>
    </div>
	
	<?php } 
	
}else{ ?> 
     <div class="no-search-user">
    Aradığın kullanıcı bulunamadı! <br />
     </div>
      <?php } ?>

</div>

<?php include 'footer.php'; ?>

</div>

<?php if($sagreklam != ""){ include 'ads/right.php'; } ?>

</div>

</div>

</body>
</html>

<?php ob_end_flush();  ?>