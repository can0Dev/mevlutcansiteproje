<?php 

if($_SESSION){
		
		header('location: '.$siteurl.'');
		
		}	

?>
<div class="share-a-confession">

<div class="siglog-t-a">
<div class="siglog-t">GİRİŞ YAP</div>
</div>

<form action="" method="post">

<div class="center">
<input type="text" class="conf-input" style="margin-top:5px;" placeholder="Kullanıcı Adı" name="username" maxlength="20" />
</div>

<div class="center">
<input type="password" class="conf-input" style="margin-top:-20px;" placeholder="Şifre" name="password" maxlength="20" />
</div>

<div class="center" style="margin-top: -10px;">

<div class="legal-chbx-a" style="width:252px; padding:8px; margin-left:-2px; margin-top:-10px;">

<div class="legal-chbx">

<input type="checkbox" id="checkboxFourInput" name="remember" <?php if(@$var == "1"){echo "checked"; } ?> style="visibility:hidden;" /> <label for="checkboxFourInput"></label> 

</div>
<div class="legal-chbx-t">
<span style="font-size: 10px; float: left; margin-top: 4px;">Oturumu açık tut</span>

<span style="font-size: 10px; float: right; margin-top: 4px;"><a href="mail/recover.php?mail=1" style="color:#222; outline:none; text-decoration:none;" rel="nofollow">Şifremi Unuttum</a></span>

</div>

</div>

</div>

<div class="center" style="margin-top:-10px;">
<input type="submit" class="conf-submit" style="width:270px; margin-top:0;" value="Giriş Yap" />
</div>

</form>

<div class="center" style="margin-top: -25px;">

<div class="signup" style="width:260px; margin-top:-14px; margin-right:0; font-family: 'Courgette', cursive;"><a href="signup">Hesabın yoksa kayıt ol</a></div>

</div>

<?php

@$username = $_POST["username"];
@$password = md5($_POST["password"]);
@$remember = $_POST["remember"];
@$login = $_POST["login"];

$l = $db->prepare("select * from uyeler where kullanici=? and sifre=?");

if($_POST){
	
$l->execute(array($username,$password));

$x = $l->fetch(PDO::FETCH_ASSOC);

$d = $l->rowCount();

	if($remember == "on"){
$cookievalue = $username."___".$password;
		setcookie("onlitm",$cookievalue,time()+60*60*24*365);
}else{
		setcookie("onlitm",$cookievalue,time()-60*60*24*365);
	}
	  
	
if($d){
	
	$_SESSION["kullanici"]  	= $x["kullanici"];
	$_SESSION["eposta"] 		= $x["eposta"];
	$_SESSION["cinsiyet"] 		= $x["cinsiyet"];
	$_SESSION["fotograf"] 		= $x["fotograf"];
	$_SESSION["sehir"] 			= $x["sehir"];
	$_SESSION["begeni"] 		= $x["begeni"];
	$_SESSION["facebook"] 		= $x["facebook"];
	$_SESSION["twitter"] 		= $x["twitter"];
	$_SESSION["instagram"] 		= $x["instagram"];
	$_SESSION["youtube"] 		= $x["youtube"];
	$_SESSION["onay"] 			= $x["onay"];
	$_SESSION["son_giris"] 		= $x["son_giris"];
	$_SESSION["kayit"] 			= $x["kayit"];
	

			
		header('location: '.$siteurl.'');
	
}else{
	
	echo '<div style="margin-top:-20px; border:2px red solid; padding:10px; background:#FFF; border-radius:5px; margin-top:3px;"><div style="color:#F00; font-size:13px;" align="center">Giriş yapılamadı.</div></div>';
	
}

}


?>


</div>
