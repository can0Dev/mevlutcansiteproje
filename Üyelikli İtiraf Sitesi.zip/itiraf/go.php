<?php 
ob_start();
session_start();

$sehir 		= $_GET["city2"];
$universt = $_GET["university"];



if($sehir){

if(empty($sehir)){
	
	header("location: ".$_SERVER['HTTP_REFERER']."");

}else{

header("location: city/".$sehir."");
	
}

}

elseif($universt){

if(empty($universt)){
	
	header("location: ".$_SERVER['HTTP_REFERER']."");

}else{

header("location: university/".$universt."");
	
}

}else{ 	header("location: ".$_SERVER['HTTP_REFERER'].""); }




 ob_end_flush();
 
?>