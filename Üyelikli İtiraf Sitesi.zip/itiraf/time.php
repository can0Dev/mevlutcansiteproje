<?php 

echo time();

?>